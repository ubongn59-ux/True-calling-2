package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object CallNotificationHelper {
    const val CHANNEL_SPAM_ALERTS = "callshield_spam_alerts"
    const val CHANNEL_CALLER_ID = "callshield_caller_id"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val spamChannel = NotificationChannel(
            CHANNEL_SPAM_ALERTS,
            "Spam & Blocked Call Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alerts when CallShield blocks spam calls or broadcasts urgent scam warnings."
        }

        val callerIdChannel = NotificationChannel(
            CHANNEL_CALLER_ID,
            "Live Caller ID",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Displays real-time caller identity and verification status during incoming calls."
        }

        manager.createNotificationChannel(spamChannel)
        manager.createNotificationChannel(callerIdChannel)
    }

    private fun canPostNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    private fun launchAppPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showBlockedCallNotification(
        context: Context,
        displayNumber: String,
        callerName: String,
        reason: String
    ) {
        if (!canPostNotifications(context)) return
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_SPAM_ALERTS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("Blocked Call: $callerName")
            .setContentText("$displayNumber • $reason")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context))
            .build()

        NotificationManagerCompat.from(context)
            .notify((System.currentTimeMillis() % 100_000).toInt(), notification)
    }

    fun showCallerIdNotification(
        context: Context,
        displayNumber: String,
        callerName: String,
        subtitle: String
    ) {
        if (!canPostNotifications(context)) return
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_CALLER_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("Caller ID: $callerName")
            .setContentText("$displayNumber • $subtitle")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context))
            .build()

        NotificationManagerCompat.from(context)
            .notify(displayNumber.hashCode(), notification)
    }

    fun showSecurityAlertNotification(context: Context, title: String, message: String) {
        if (!canPostNotifications(context)) return
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_SPAM_ALERTS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("CallShield Alert: $title")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context))
            .build()

        NotificationManagerCompat.from(context)
            .notify(title.hashCode(), notification)
    }
}
