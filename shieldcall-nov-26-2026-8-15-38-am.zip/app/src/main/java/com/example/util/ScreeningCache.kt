package com.example.util

import android.content.Context
import com.example.data.model.BlockedNumber
import com.example.data.model.CallerDirectoryEntry
import com.google.firebase.Timestamp
import org.json.JSONArray
import org.json.JSONObject

data class CachedDirectoryMatch(
    val numberKey: String,
    val callerName: String,
    val category: String,
    val spamScore: Int,
    val verifiedBusiness: Boolean
)

data class PendingScreenedEvent(
    val phoneNumber: String,
    val callerName: String,
    val actionTaken: String,
    val spamScore: Int,
    val stirVerification: String,
    val occurredAtMillis: Long
)

class ScreeningCache(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isGuestMode: Boolean
        get() = prefs.getBoolean(KEY_GUEST_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_GUEST_MODE, value).apply()

    var guestThemeMode: String
        get() = prefs.getString(KEY_GUEST_THEME_MODE, "SYSTEM") ?: "SYSTEM"
        set(value) = prefs.edit().putString(KEY_GUEST_THEME_MODE, value).apply()

    var spamProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_PROTECTION_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECTION_ENABLED, value).apply()

    var autoBlockHighRisk: Boolean
        get() = prefs.getBoolean(KEY_AUTO_BLOCK_HIGH_RISK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_BLOCK_HIGH_RISK, value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply()

    fun syncBlockedNumbers(items: List<BlockedNumber>) {
        val mapJson = JSONObject()
        items.forEach { item ->
            val obj = JSONObject().apply {
                put("label", item.label)
                put("blockMode", item.blockMode)
                put("rawNumber", item.rawNumber)
                put("reason", item.reason)
                put("createdAtSeconds", item.createdAt?.seconds ?: (System.currentTimeMillis() / 1000L))
            }
            mapJson.put(item.phoneNumber, obj)
        }
        prefs.edit().putString(KEY_BLOCKED_MAP, mapJson.toString()).apply()
    }

    fun getBlockedNumbersList(): List<BlockedNumber> {
        val raw = prefs.getString(KEY_BLOCKED_MAP, null) ?: return emptyList()
        return try {
            val root = JSONObject(raw)
            val keys = root.keys()
            buildList {
                while (keys.hasNext()) {
                    val numberKey = keys.next()
                    val obj = root.optJSONObject(numberKey) ?: continue
                    val createdSec = obj.optLong("createdAtSeconds", 0L)
                    add(
                        BlockedNumber(
                            id = numberKey,
                            userId = "guest",
                            phoneNumber = numberKey,
                            rawNumber = obj.optString("rawNumber", PhoneNumberNormalizer.formatDisplay(numberKey)),
                            label = obj.optString("label", "Blocked Caller"),
                            reason = obj.optString("reason", "Blocked locally"),
                            blockMode = obj.optString("blockMode", "REJECT"),
                            createdAt = if (createdSec > 0L) Timestamp(createdSec, 0) else null
                        )
                    )
                }
            }.sortedByDescending { it.createdAt?.seconds ?: 0L }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun upsertLocalBlockedNumber(
        rawNumber: String,
        label: String,
        reason: String,
        blockMode: String
    ): Result<Unit> {
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        if (numberKey.length !in 3..24) {
            return Result.failure(IllegalArgumentException("Enter a valid phone number (at least 3 digits)."))
        }
        val formatted = PhoneNumberNormalizer.formatDisplay(rawNumber).take(30)
        val safeMode = if (blockMode in listOf("REJECT", "SILENCE")) blockMode else "REJECT"
        val existingRaw = prefs.getString(KEY_BLOCKED_MAP, null)
        val root = try {
            if (existingRaw != null) JSONObject(existingRaw) else JSONObject()
        } catch (_: Exception) {
            JSONObject()
        }
        val prev = root.optJSONObject(numberKey)
        val createdSec = prev?.optLong("createdAtSeconds", 0L)?.takeIf { it > 0L }
            ?: (System.currentTimeMillis() / 1000L)
        val entry = JSONObject().apply {
            put("label", label.trim().take(80))
            put("reason", reason.trim().take(160))
            put("blockMode", safeMode)
            put("rawNumber", formatted)
            put("createdAtSeconds", createdSec)
        }
        root.put(numberKey, entry)
        prefs.edit().putString(KEY_BLOCKED_MAP, root.toString()).apply()
        return Result.success(Unit)
    }

    fun removeLocalBlockedNumber(numberKey: String) {
        val existingRaw = prefs.getString(KEY_BLOCKED_MAP, null) ?: return
        try {
            val root = JSONObject(existingRaw)
            root.remove(numberKey)
            prefs.edit().putString(KEY_BLOCKED_MAP, root.toString()).apply()
        } catch (_: Exception) {
            // Ignore malformed JSON
        }
    }

    fun toggleLocalBlockMode(numberKey: String): String? {
        val existingRaw = prefs.getString(KEY_BLOCKED_MAP, null) ?: return null
        return try {
            val root = JSONObject(existingRaw)
            val entry = root.optJSONObject(numberKey) ?: return null
            val currentMode = entry.optString("blockMode", "REJECT")
            val nextMode = if (currentMode == "REJECT") "SILENCE" else "REJECT"
            entry.put("blockMode", nextMode)
            root.put(numberKey, entry)
            prefs.edit().putString(KEY_BLOCKED_MAP, root.toString()).apply()
            nextMode
        } catch (_: Exception) {
            null
        }
    }

    fun getBlockedMode(numberKey: String): Pair<String, String>? {
        val raw = prefs.getString(KEY_BLOCKED_MAP, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val entry = root.optJSONObject(numberKey) ?: return null
            val label = entry.optString("label", "Blocked Caller")
            val mode = entry.optString("blockMode", "REJECT")
            label to mode
        } catch (_: Exception) {
            null
        }
    }

    fun syncDirectoryEntries(entries: List<CallerDirectoryEntry>) {
        val mapJson = JSONObject()
        entries.take(500).forEach { entry ->
            val obj = JSONObject().apply {
                put("callerName", entry.callerName)
                put("displayNumber", entry.displayNumber)
                put("category", entry.category)
                put("spamScore", entry.spamScore.toInt())
                put("verifiedBusiness", entry.verifiedBusiness)
            }
            mapJson.put(entry.numberKey, obj)
        }
        prefs.edit().putString(KEY_DIRECTORY_MAP, mapJson.toString()).apply()
    }

    fun getCachedDirectoryEntries(): List<CallerDirectoryEntry> {
        val raw = prefs.getString(KEY_DIRECTORY_MAP, null) ?: return emptyList()
        return try {
            val root = JSONObject(raw)
            val keys = root.keys()
            buildList {
                while (keys.hasNext()) {
                    val numberKey = keys.next()
                    val obj = root.optJSONObject(numberKey) ?: continue
                    add(
                        CallerDirectoryEntry(
                            id = numberKey,
                            numberKey = numberKey,
                            displayNumber = obj.optString("displayNumber", PhoneNumberNormalizer.formatDisplay(numberKey)),
                            callerName = obj.optString("callerName", "Unknown Caller"),
                            category = obj.optString("category", "COMMUNITY"),
                            spamScore = obj.optInt("spamScore", 0).toLong(),
                            verifiedBusiness = obj.optBoolean("verifiedBusiness", false)
                        )
                    )
                }
            }.sortedByDescending { it.spamScore }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun findDirectoryMatch(numberKey: String): CachedDirectoryMatch? {
        val raw = prefs.getString(KEY_DIRECTORY_MAP, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val obj = root.optJSONObject(numberKey) ?: return null
            CachedDirectoryMatch(
                numberKey = numberKey,
                callerName = obj.optString("callerName", "Unknown Caller"),
                category = obj.optString("category", "COMMUNITY"),
                spamScore = obj.optInt("spamScore", 0),
                verifiedBusiness = obj.optBoolean("verifiedBusiness", false)
            )
        } catch (_: Exception) {
            null
        }
    }

    fun enqueueScreenedEvent(event: PendingScreenedEvent) {
        val existingRaw = prefs.getString(KEY_PENDING_EVENTS, "[]") ?: "[]"
        val arr = try {
            JSONArray(existingRaw)
        } catch (_: Exception) {
            JSONArray()
        }
        val obj = JSONObject().apply {
            put("phoneNumber", event.phoneNumber)
            put("callerName", event.callerName)
            put("actionTaken", event.actionTaken)
            put("spamScore", event.spamScore)
            put("stirVerification", event.stirVerification)
            put("occurredAtMillis", event.occurredAtMillis)
        }
        arr.put(obj)
        prefs.edit().putString(KEY_PENDING_EVENTS, arr.toString()).apply()
    }

    fun peekPendingScreenedEvents(): List<PendingScreenedEvent> {
        val existingRaw = prefs.getString(KEY_PENDING_EVENTS, null) ?: return emptyList()
        return parsePendingEvents(existingRaw)
    }

    fun drainPendingScreenedEvents(): List<PendingScreenedEvent> {
        val existingRaw = prefs.getString(KEY_PENDING_EVENTS, null) ?: return emptyList()
        prefs.edit().remove(KEY_PENDING_EVENTS).apply()
        return parsePendingEvents(existingRaw)
    }

    private fun parsePendingEvents(existingRaw: String): List<PendingScreenedEvent> {
        return try {
            val arr = JSONArray(existingRaw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        PendingScreenedEvent(
                            phoneNumber = obj.optString("phoneNumber"),
                            callerName = obj.optString("callerName"),
                            actionTaken = obj.optString("actionTaken", "ALLOWED"),
                            spamScore = obj.optInt("spamScore", 0),
                            stirVerification = obj.optString("stirVerification", "NOT_VERIFIED"),
                            occurredAtMillis = obj.optLong("occurredAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private companion object {
        const val PREFS_NAME = "callshield_screening_cache"
        const val KEY_GUEST_MODE = "guest_mode_enabled"
        const val KEY_GUEST_THEME_MODE = "guest_theme_mode"
        const val KEY_PROTECTION_ENABLED = "spam_protection_enabled"
        const val KEY_AUTO_BLOCK_HIGH_RISK = "auto_block_high_risk"
        const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        const val KEY_BLOCKED_MAP = "blocked_map_json"
        const val KEY_DIRECTORY_MAP = "directory_map_json"
        const val KEY_PENDING_EVENTS = "pending_screened_events"
    }
}
