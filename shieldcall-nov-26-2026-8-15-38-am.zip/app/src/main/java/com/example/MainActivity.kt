package com.example

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.UiState
import com.example.data.repository.AuthManager
import com.example.data.repository.DirectoryAdminRepository
import com.example.data.repository.UserProtectionRepository
import com.example.service.DeviceContentReader
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallerDetailSheet
import com.example.ui.screens.CallsScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.LookupScreen
import com.example.ui.screens.ShieldScreen
import com.example.ui.theme.CallShieldTheme
import com.example.ui.theme.ThemeMode
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.CallShieldViewModel
import com.example.ui.viewmodel.GuestCallShieldViewModel
import com.example.util.CallNotificationHelper
import com.example.util.ScreeningCache
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

const val ROUTE_CALLS = "calls"
const val ROUTE_LOOKUP = "lookup"
const val ROUTE_CONTACTS = "contacts"
const val ROUTE_SHIELD = "shield"
const val ROUTE_ADMIN = "admin"

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        CallNotificationHelper.createChannels(this)
        setContent {
            AppRoot()
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val screeningCache = remember(context) { ScreeningCache(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var isGuestMode by remember {
        mutableStateOf(Firebase.auth.currentUser == null && screeningCache.isGuestMode)
    }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
            if (auth.currentUser != null) {
                screeningCache.isGuestMode = false
                isGuestMode = false
            }
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null && !isGuestMode) {
            AuthManager.attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                scope = scope,
                onAuthSuccess = {
                    screeningCache.isGuestMode = false
                    isGuestMode = false
                    currentUser = Firebase.auth.currentUser
                },
                onUnauthenticated = {}
            )
        }
    }

    val user = currentUser
    when {
        user != null -> {
            key(user.uid) {
                AuthenticatedCallShieldApp(
                    currentUserId = user.uid,
                    onSignOut = {
                        AuthManager.signOut(credentialManager, scope) {
                            screeningCache.isGuestMode = false
                            isGuestMode = false
                            currentUser = null
                        }
                    }
                )
            }
        }
        isGuestMode -> {
            key("guest") {
                GuestCallShieldApp(
                    onRequestGoogleSignIn = {
                        AuthManager.cancelAutoSignIn()
                        screeningCache.isGuestMode = false
                        isGuestMode = false
                    },
                    onExitGuestMode = {
                        screeningCache.isGuestMode = false
                        isGuestMode = false
                    }
                )
            }
        }
        else -> {
            CallShieldTheme(themeMode = ThemeMode.SYSTEM) {
                AuthScreen(
                    onAuthSuccess = {
                        screeningCache.isGuestMode = false
                        isGuestMode = false
                        currentUser = Firebase.auth.currentUser
                    },
                    onContinueAsGuest = {
                        AuthManager.cancelAutoSignIn()
                        screeningCache.isGuestMode = true
                        isGuestMode = true
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedCallShieldApp(
    currentUserId: String,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current

    val mainViewModel: CallShieldViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                CallShieldViewModel(
                    currentUserId = currentUserId,
                    userRepo = UserProtectionRepository(db),
                    directoryRepo = DirectoryAdminRepository(db),
                    screeningCache = ScreeningCache(app)
                )
            }
        }
    )

    val profileState by mainViewModel.userProfileState.collectAsStateWithLifecycle()
    val themeMode by mainViewModel.themeMode.collectAsStateWithLifecycle()
    val isAdmin by mainViewModel.isAdmin.collectAsStateWithLifecycle()
    val blockedState by mainViewModel.blockedNumbersState.collectAsStateWithLifecycle()
    val unifiedCalls by mainViewModel.unifiedCalls.collectAsStateWithLifecycle()
    val publicDirectory by mainViewModel.publicDirectory.collectAsStateWithLifecycle()
    val verifiedBusinesses by mainViewModel.verifiedBusinesses.collectAsStateWithLifecycle()
    val myBusinessApps by mainViewModel.myBusinessApplications.collectAsStateWithLifecycle()
    val mySpamReports by mainViewModel.mySpamReports.collectAsStateWithLifecycle()
    val systemAlerts by mainViewModel.systemAlerts.collectAsStateWithLifecycle()
    val deviceContacts by mainViewModel.deviceContacts.collectAsStateWithLifecycle()
    val searchQuery by mainViewModel.searchQuery.collectAsStateWithLifecycle()
    val inspectedLookup by mainViewModel.inspectedLookupResult.collectAsStateWithLifecycle()

    val profile = (profileState as? UiState.Success)?.data
    val blockedList = (blockedState as? UiState.Success)?.data.orEmpty()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(mainViewModel) {
        mainViewModel.snackbarEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    var hasCallLogPermission by remember { mutableStateOf(DeviceContentReader.hasCallLogPermission(context)) }
    var hasContactsPermission by remember { mutableStateOf(DeviceContentReader.hasContactsPermission(context)) }
    var hasCallScreeningRole by remember { mutableStateOf(checkCallScreeningRole(context)) }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasCallLogPermission = DeviceContentReader.hasCallLogPermission(context)
        hasContactsPermission = DeviceContentReader.hasContactsPermission(context)
        mainViewModel.refreshDeviceData(context)
    }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            mainViewModel.updatePreferences(
                spamProtectionEnabled = profile?.spamProtectionEnabled ?: true,
                autoBlockHighRisk = profile?.autoBlockHighRisk ?: true,
                notificationsEnabled = false,
                themeMode = themeMode
            )
        }
    }

    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasCallScreeningRole = checkCallScreeningRole(context)
    }

    LaunchedEffect(currentUserId) {
        mainViewModel.refreshDeviceData(context)
    }

    var lastNotifiedAlertId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(systemAlerts, profile?.notificationsEnabled) {
        val newest = systemAlerts.firstOrNull()
        if (newest != null &&
            newest.id != lastNotifiedAlertId &&
            (newest.severity == "CRITICAL" || newest.severity == "WARNING") &&
            profile?.notificationsEnabled == true
        ) {
            lastNotifiedAlertId = newest.id
            CallNotificationHelper.showSecurityAlertNotification(context, newest.title, newest.message)
        }
    }

    val requestCallAndContactPermissions: () -> Unit = {
        val needed = buildList {
            if (!DeviceContentReader.hasCallLogPermission(context)) add(Manifest.permission.READ_CALL_LOG)
            if (!DeviceContentReader.hasContactsPermission(context)) add(Manifest.permission.READ_CONTACTS)
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.READ_PHONE_STATE)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (needed.isNotEmpty()) {
            permissionsLauncher.launch(needed.toTypedArray())
        } else {
            mainViewModel.refreshDeviceData(context)
        }
    }

    val requestCallScreeningRole: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                } else {
                    hasCallScreeningRole = true
                }
            }
        }
    }

    val requestNotificationPerm: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_CALLS

    val baseDestinations = listOf(
        NavDestinationItem(ROUTE_CALLS, stringResource(R.string.tab_calls), Icons.Filled.Call, Icons.Outlined.Call),
        NavDestinationItem(ROUTE_LOOKUP, stringResource(R.string.tab_search), Icons.Filled.Search, Icons.Outlined.Search),
        NavDestinationItem(ROUTE_CONTACTS, stringResource(R.string.tab_contacts), Icons.Filled.Contacts, Icons.Outlined.Contacts),
        NavDestinationItem(ROUTE_SHIELD, stringResource(R.string.tab_shield), Icons.Filled.Shield, Icons.Outlined.Shield),
    )
    val destinations = if (isAdmin) {
        baseDestinations + NavDestinationItem(
            ROUTE_ADMIN,
            stringResource(R.string.tab_admin),
            Icons.Filled.AdminPanelSettings,
            Icons.Outlined.AdminPanelSettings
        )
    } else {
        baseDestinations
    }

    val navigateToTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    CallShieldTheme(themeMode = themeMode) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                },
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    modifier = Modifier.testTag("rail_${dest.route}")
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_CALLS,
                            enterTransition = { fadeIn(tween(220)) },
                            exitTransition = { fadeOut(tween(180)) }
                        ) {
                            composable(ROUTE_CALLS) {
                                CallsScreen(
                                    profile = profile,
                                    calls = unifiedCalls,
                                    alerts = systemAlerts,
                                    hasCallLogPermission = hasCallLogPermission,
                                    hasCallScreeningRole = hasCallScreeningRole,
                                    onRequestCallScreeningRole = requestCallScreeningRole,
                                    onRequestPermissions = requestCallAndContactPermissions,
                                    onRefreshLogs = { mainViewModel.refreshDeviceData(context) },
                                    onInspectNumber = { mainViewModel.inspectNumber(it) },
                                    onQuickSearchClick = { navigateToTab(ROUTE_LOOKUP) }
                                )
                            }

                            composable(ROUTE_LOOKUP) {
                                LookupScreen(
                                    searchQuery = searchQuery,
                                    directory = publicDirectory,
                                    verifiedBusinesses = verifiedBusinesses,
                                    onSearchQueryChange = { mainViewModel.updateSearchQuery(it) },
                                    onInspectNumber = { mainViewModel.inspectNumber(it) },
                                    onSubmitReport = { num, name, cat, comment ->
                                        mainViewModel.submitSpamReport(num, name, cat, comment)
                                    }
                                )
                            }

                            composable(ROUTE_CONTACTS) {
                                ContactsScreen(
                                    contacts = deviceContacts,
                                    directory = publicDirectory,
                                    blockedNumbers = blockedList,
                                    hasContactsPermission = hasContactsPermission,
                                    onRequestContactsPermission = requestCallAndContactPermissions,
                                    onInspectNumber = { mainViewModel.inspectNumber(it) }
                                )
                            }

                            composable(ROUTE_SHIELD) {
                                ShieldScreen(
                                    profile = profile,
                                    isAdmin = isAdmin,
                                    isGuestMode = false,
                                    blockedNumbers = blockedList,
                                    myReports = mySpamReports,
                                    myBusinessApplications = myBusinessApps,
                                    systemAlerts = systemAlerts,
                                    themeMode = themeMode,
                                    hasCallScreeningRole = hasCallScreeningRole,
                                    onRequestCallScreeningRole = requestCallScreeningRole,
                                    onRequestNotificationPermission = requestNotificationPerm,
                                    onUpdatePreferences = { sp, ab, notif, theme ->
                                        mainViewModel.updatePreferences(sp, ab, notif, theme)
                                    },
                                    onUpdateProfile = { name, phone ->
                                        mainViewModel.updateProfileDetails(name, phone)
                                    },
                                    onBlockNumber = { num, label, reason, mode ->
                                        mainViewModel.blockNumber(num, label, reason, mode)
                                    },
                                    onUnblockNumber = { mainViewModel.unblockNumber(it) },
                                    onToggleBlockMode = { mainViewModel.toggleBlockMode(it) },
                                    onSubmitBusinessVerification = { name, num, cat, web, desc ->
                                        mainViewModel.submitBusinessVerification(name, num, cat, web, desc)
                                    },
                                    onSignOut = onSignOut
                                )
                            }

                            if (isAdmin) {
                                composable(ROUTE_ADMIN) {
                                    val adminViewModel: AdminViewModel = viewModel(
                                        key = "admin_$currentUserId",
                                        factory = viewModelFactory {
                                            initializer {
                                                val app = checkNotNull(this[APPLICATION_KEY])
                                                val db = FirebaseFirestore.getInstance(
                                                    app.getString(R.string.firestore_database_id)
                                                )
                                                AdminViewModel(
                                                    currentUserId = currentUserId,
                                                    directoryRepo = DirectoryAdminRepository(db)
                                                )
                                            }
                                        }
                                    )

                                    LaunchedEffect(adminViewModel) {
                                        adminViewModel.adminFeedback.collect { msg ->
                                            snackbarHostState.showSnackbar(msg)
                                        }
                                    }

                                    val pendingReports by adminViewModel.pendingReportsState.collectAsStateWithLifecycle()
                                    val pendingBusinesses by adminViewModel.pendingBusinessesState.collectAsStateWithLifecycle()
                                    val allUsers by adminViewModel.allUsers.collectAsStateWithLifecycle()
                                    val adminsList by adminViewModel.adminsList.collectAsStateWithLifecycle()

                                    AdminScreen(
                                        pendingReportsState = pendingReports,
                                        pendingBusinessesState = pendingBusinesses,
                                        directoryEntries = publicDirectory,
                                        allUsers = allUsers,
                                        adminsList = adminsList,
                                        systemAlerts = systemAlerts,
                                        onModerateReport = { rep, approve -> adminViewModel.moderateReport(rep, approve) },
                                        onModerateBusiness = { biz, approve -> adminViewModel.moderateBusiness(biz, approve) },
                                        onUpsertDirectoryEntry = { num, name, cat, score, verified, vis ->
                                            adminViewModel.upsertDirectoryEntry(num, name, cat, score, verified, vis)
                                        },
                                        onDeleteDirectoryEntry = { adminViewModel.deleteDirectoryEntry(it) },
                                        onPublishAlert = { title, msg, sev -> adminViewModel.publishAlert(title, msg, sev) },
                                        onDeleteAlert = { adminViewModel.deleteAlert(it) },
                                        onGrantAdmin = { uid, email, name -> adminViewModel.grantAdmin(uid, email, name) },
                                        onRevokeAdmin = { adminViewModel.revokeAdmin(it) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            val currentLookup = inspectedLookup
            if (currentLookup != null) {
                CallerDetailSheet(
                    lookup = currentLookup,
                    onDismiss = { mainViewModel.dismissInspector() },
                    onBlock = { num, label, reason, mode ->
                        mainViewModel.blockNumber(num, label, reason, mode)
                    },
                    onUnblock = { blockId -> mainViewModel.unblockNumber(blockId) },
                    onSubmitReport = { num, name, cat, comment ->
                        mainViewModel.submitSpamReport(num, name, cat, comment)
                    },
                    onSubmitRating = { num, stars, review ->
                        mainViewModel.submitCallerRating(num, stars, review)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GuestCallShieldApp(
    onRequestGoogleSignIn: () -> Unit,
    onExitGuestMode: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val guestViewModel: GuestCallShieldViewModel = viewModel(
        key = "guest_vm",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                GuestCallShieldViewModel(ScreeningCache(app))
            }
        }
    )

    val profile by guestViewModel.guestProfile.collectAsStateWithLifecycle()
    val themeMode by guestViewModel.themeMode.collectAsStateWithLifecycle()
    val blockedList by guestViewModel.blockedNumbers.collectAsStateWithLifecycle()
    val unifiedCalls by guestViewModel.unifiedCalls.collectAsStateWithLifecycle()
    val cachedDirectory by guestViewModel.cachedDirectory.collectAsStateWithLifecycle()
    val deviceContacts by guestViewModel.deviceContacts.collectAsStateWithLifecycle()
    val searchQuery by guestViewModel.searchQuery.collectAsStateWithLifecycle()
    val inspectedLookup by guestViewModel.inspectedLookupResult.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var signInPromptMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(guestViewModel) {
        guestViewModel.snackbarEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    LaunchedEffect(guestViewModel) {
        guestViewModel.signInPromptEvents.collect { message ->
            signInPromptMessage = message
        }
    }

    var hasCallLogPermission by remember { mutableStateOf(DeviceContentReader.hasCallLogPermission(context)) }
    var hasContactsPermission by remember { mutableStateOf(DeviceContentReader.hasContactsPermission(context)) }
    var hasCallScreeningRole by remember { mutableStateOf(checkCallScreeningRole(context)) }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasCallLogPermission = DeviceContentReader.hasCallLogPermission(context)
        hasContactsPermission = DeviceContentReader.hasContactsPermission(context)
        guestViewModel.refreshDeviceData(context)
    }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            guestViewModel.updatePreferences(
                spamProtectionEnabled = profile.spamProtectionEnabled,
                autoBlockHighRisk = profile.autoBlockHighRisk,
                notificationsEnabled = false,
                themeMode = themeMode
            )
        }
    }

    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasCallScreeningRole = checkCallScreeningRole(context)
    }

    LaunchedEffect(Unit) {
        guestViewModel.refreshDeviceData(context)
    }

    val requestCallAndContactPermissions: () -> Unit = {
        val needed = buildList {
            if (!DeviceContentReader.hasCallLogPermission(context)) add(Manifest.permission.READ_CALL_LOG)
            if (!DeviceContentReader.hasContactsPermission(context)) add(Manifest.permission.READ_CONTACTS)
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.READ_PHONE_STATE)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (needed.isNotEmpty()) {
            permissionsLauncher.launch(needed.toTypedArray())
        } else {
            guestViewModel.refreshDeviceData(context)
        }
    }

    val requestCallScreeningRole: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                } else {
                    hasCallScreeningRole = true
                }
            }
        }
    }

    val requestNotificationPerm: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val launchInteractiveGoogleSignIn: () -> Unit = {
        AuthManager.onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            scope = scope,
            onAuthSuccess = { onRequestGoogleSignIn() },
            onAuthError = { msg ->
                scope.launch {
                    snackbarHostState.showSnackbar(msg)
                }
            },
            onAuthCancelled = {
                scope.launch {
                    snackbarHostState.showSnackbar("Google Sign-In was dismissed.")
                }
            }
        )
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_CALLS

    val destinations = listOf(
        NavDestinationItem(ROUTE_CALLS, stringResource(R.string.tab_calls), Icons.Filled.Call, Icons.Outlined.Call),
        NavDestinationItem(ROUTE_LOOKUP, stringResource(R.string.tab_search), Icons.Filled.Search, Icons.Outlined.Search),
        NavDestinationItem(ROUTE_CONTACTS, stringResource(R.string.tab_contacts), Icons.Filled.Contacts, Icons.Outlined.Contacts),
        NavDestinationItem(ROUTE_SHIELD, stringResource(R.string.tab_shield), Icons.Filled.Shield, Icons.Outlined.Shield),
    )

    val navigateToTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    CallShieldTheme(themeMode = themeMode) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                text = "${stringResource(R.string.app_name)} • Guest",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                },
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    modifier = Modifier.testTag("rail_${dest.route}")
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_CALLS,
                            enterTransition = { fadeIn(tween(220)) },
                            exitTransition = { fadeOut(tween(180)) }
                        ) {
                            composable(ROUTE_CALLS) {
                                CallsScreen(
                                    profile = profile,
                                    calls = unifiedCalls,
                                    alerts = emptyList(),
                                    hasCallLogPermission = hasCallLogPermission,
                                    hasCallScreeningRole = hasCallScreeningRole,
                                    onRequestCallScreeningRole = requestCallScreeningRole,
                                    onRequestPermissions = requestCallAndContactPermissions,
                                    onRefreshLogs = { guestViewModel.refreshDeviceData(context) },
                                    onInspectNumber = { guestViewModel.inspectNumber(it) },
                                    onQuickSearchClick = { navigateToTab(ROUTE_LOOKUP) }
                                )
                            }

                            composable(ROUTE_LOOKUP) {
                                LookupScreen(
                                    searchQuery = searchQuery,
                                    directory = cachedDirectory,
                                    verifiedBusinesses = emptyList(),
                                    onSearchQueryChange = { guestViewModel.updateSearchQuery(it) },
                                    onInspectNumber = { guestViewModel.inspectNumber(it) },
                                    onSubmitReport = { _, _, _, _ ->
                                        guestViewModel.promptGoogleSignInForCloudFeature("submit community spam reports")
                                    }
                                )
                            }

                            composable(ROUTE_CONTACTS) {
                                ContactsScreen(
                                    contacts = deviceContacts,
                                    directory = cachedDirectory,
                                    blockedNumbers = blockedList,
                                    hasContactsPermission = hasContactsPermission,
                                    onRequestContactsPermission = requestCallAndContactPermissions,
                                    onInspectNumber = { guestViewModel.inspectNumber(it) }
                                )
                            }

                            composable(ROUTE_SHIELD) {
                                ShieldScreen(
                                    profile = profile,
                                    isAdmin = false,
                                    isGuestMode = true,
                                    blockedNumbers = blockedList,
                                    myReports = emptyList(),
                                    myBusinessApplications = emptyList(),
                                    systemAlerts = emptyList(),
                                    themeMode = themeMode,
                                    hasCallScreeningRole = hasCallScreeningRole,
                                    onRequestCallScreeningRole = requestCallScreeningRole,
                                    onRequestNotificationPermission = requestNotificationPerm,
                                    onUpdatePreferences = { sp, ab, notif, theme ->
                                        guestViewModel.updatePreferences(sp, ab, notif, theme)
                                    },
                                    onUpdateProfile = { _, _ -> },
                                    onBlockNumber = { num, label, reason, mode ->
                                        guestViewModel.blockNumber(num, label, reason, mode)
                                    },
                                    onUnblockNumber = { guestViewModel.unblockNumber(it) },
                                    onToggleBlockMode = { guestViewModel.toggleBlockMode(it) },
                                    onSubmitBusinessVerification = { _, _, _, _, _ ->
                                        guestViewModel.promptGoogleSignInForCloudFeature("apply for a Verified Business badge")
                                    },
                                    onSignInWithGoogle = launchInteractiveGoogleSignIn,
                                    onSignOut = onExitGuestMode
                                )
                            }
                        }
                    }
                }
            }

            val currentLookup = inspectedLookup
            if (currentLookup != null) {
                CallerDetailSheet(
                    lookup = currentLookup,
                    onDismiss = { guestViewModel.dismissInspector() },
                    onBlock = { num, label, reason, mode ->
                        guestViewModel.blockNumber(num, label, reason, mode)
                    },
                    onUnblock = { blockId -> guestViewModel.unblockNumber(blockId) },
                    onSubmitReport = { _, _, _, _ ->
                        guestViewModel.promptGoogleSignInForCloudFeature("submit community spam reports")
                    },
                    onSubmitRating = { _, _, _ ->
                        guestViewModel.promptGoogleSignInForCloudFeature("rate callers and post reviews")
                    }
                )
            }

            if (signInPromptMessage != null) {
                AlertDialog(
                    onDismissRequest = { signInPromptMessage = null },
                    title = { Text(stringResource(R.string.sign_in_required_title)) },
                    text = { Text(signInPromptMessage.orEmpty()) },
                    confirmButton = {
                        Button(
                            onClick = {
                                signInPromptMessage = null
                                launchInteractiveGoogleSignIn()
                            },
                            modifier = Modifier.testTag("prompt_google_sign_in_button")
                        ) {
                            Text(stringResource(R.string.sign_in_google))
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { signInPromptMessage = null }) {
                            Text("Stay in Guest Mode")
                        }
                    }
                )
            }
        }
    }
}

private fun checkCallScreeningRole(context: Context): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return true
    val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
    return roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
        roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
}
