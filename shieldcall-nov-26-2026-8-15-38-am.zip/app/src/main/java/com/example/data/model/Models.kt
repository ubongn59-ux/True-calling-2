package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String? = null,
    val phoneNumber: String? = null,
    val photoUrl: String? = null,
    val role: String = "USER",
    val spamProtectionEnabled: Boolean = true,
    val autoBlockHighRisk: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val themeMode: String = "SYSTEM",
    val totalCallsScreened: Long = 0L,
    val totalSpamBlocked: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BlockedNumber(
    @DocumentId val id: String = "",
    val userId: String = "",
    val phoneNumber: String = "",
    val rawNumber: String = "",
    val label: String = "",
    val reason: String = "",
    val blockMode: String = "REJECT",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallEvent(
    @DocumentId val id: String = "",
    val userId: String = "",
    val phoneNumber: String = "",
    val callerName: String = "",
    val callDirection: String = "INCOMING",
    val actionTaken: String = "ALLOWED",
    val spamScore: Long = 0L,
    val stirVerification: String = "NOT_VERIFIED",
    val durationSeconds: Long = 0L,
    val occurredAtMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallerDirectoryEntry(
    @DocumentId val id: String = "",
    val numberKey: String = "",
    val displayNumber: String = "",
    val callerName: String = "",
    val category: String = "COMMUNITY",
    val verifiedBusiness: Boolean = false,
    val visibility: String = "PUBLIC",
    val spamReportsCount: Long = 0L,
    val safeReportsCount: Long = 0L,
    val spamScore: Long = 0L,
    val averageRating: Double = 0.0,
    val ratingsCount: Long = 0L,
    val lastReportedTag: String = "",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SpamReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val numberKey: String = "",
    val displayNumber: String = "",
    val reportedName: String = "",
    val category: String = "SCAM_FRAUD",
    val comment: String = "",
    val status: String = "PENDING",
    val reviewedBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallerRating(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val numberKey: String = "",
    val stars: Long = 5L,
    val review: String = "",
    val visibility: String = "PUBLIC",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class VerifiedBusiness(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val businessName: String = "",
    val numberKey: String = "",
    val displayNumber: String = "",
    val category: String = "",
    val website: String = "",
    val description: String = "",
    val verificationStatus: String = "PENDING",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SystemAlert(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val severity: String = "INFO",
    val targetScope: String = "ALL_USERS",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AdminMember(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val grantedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class DeviceCallLogItem(
    val id: String,
    val phoneNumber: String,
    val numberKey: String,
    val cachedContactName: String?,
    val callType: String,
    val timestampMillis: Long,
    val durationSeconds: Long
)

data class DeviceContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val numberKey: String,
    val label: String
)

data class UnifiedCallRecord(
    val id: String,
    val rawNumber: String,
    val numberKey: String,
    val displayName: String,
    val direction: String,
    val actionTaken: String,
    val spamScore: Int,
    val verifiedBusiness: Boolean,
    val category: String,
    val stirVerification: String,
    val isBlocked: Boolean,
    val isContact: Boolean,
    val timestampMillis: Long,
    val durationSeconds: Long,
    val isCloudEvent: Boolean
)

data class CallerLookupResult(
    val numberKey: String,
    val displayNumber: String,
    val resolvedName: String,
    val directoryEntry: CallerDirectoryEntry?,
    val matchedContact: DeviceContactItem?,
    val blockedEntry: BlockedNumber?,
    val ratings: List<CallerRating>,
    val approvedReports: List<SpamReport>
)
