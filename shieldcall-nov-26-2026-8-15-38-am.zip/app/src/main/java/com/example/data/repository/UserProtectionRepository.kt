package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.BlockedNumber
import com.example.data.model.CallEvent
import com.example.data.model.SystemAlert
import com.example.data.model.UserProfile
import com.example.util.OperationType
import com.example.util.PhoneNumberNormalizer
import com.example.util.handleFirestoreError
import com.example.util.unwrapFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserProtectionRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun ensureUserProfile(user: FirebaseUser): Result<Unit> {
        val path = "users/${user.uid}"
        return try {
            val uid = requireUserId()
            check(uid == user.uid) { "Signed-in user mismatch" }
            val docRef = db.collection("users").document(uid)
            val snapshot = docRef.get().await()
            val isBootstrapAdmin = user.isEmailVerified &&
                user.email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)

            val cleanEmail = user.email?.trim()?.takeIf { it.isNotBlank() }?.take(120)
            val cleanPhoto = user.photoUrl?.toString()?.trim()?.takeIf { it.isNotBlank() }?.take(500)

            if (!snapshot.exists()) {
                val safeName = (user.displayName ?: cleanEmail?.substringBefore("@") ?: "CallShield User")
                    .trim()
                    .take(80)
                    .ifBlank { "CallShield User" }
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", safeName)
                    if (cleanEmail != null) put("email", cleanEmail)
                    if (cleanPhoto != null) put("photoUrl", cleanPhoto)
                    put("role", if (isBootstrapAdmin) "ADMIN" else "USER")
                    put("spamProtectionEnabled", true)
                    put("autoBlockHighRisk", true)
                    put("notificationsEnabled", true)
                    put("themeMode", "SYSTEM")
                    put("totalCallsScreened", 0L)
                    put("totalSpamBlocked", 0L)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>()
                if (isBootstrapAdmin && snapshot.getString("role") != "ADMIN") {
                    updates["role"] = "ADMIN"
                }
                if (cleanEmail != null && snapshot.getString("email").isNullOrBlank()) {
                    updates["email"] = cleanEmail
                }
                if (cleanPhoto != null && snapshot.getString("photoUrl").isNullOrBlank()) {
                    updates["photoUrl"] = cleanPhoto
                }
                if (updates.isNotEmpty()) {
                    updates["updatedAt"] = FieldValue.serverTimestamp()
                    docRef.update(updates).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun ensureProfileExistsBeforeUpdate(uid: String) {
        val docRef = db.collection("users").document(uid)
        if (!docRef.get().await().exists()) {
            val user = auth.currentUser
            if (user != null && user.uid == uid) {
                ensureUserProfile(user).getOrThrow()
            }
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeIsAdmin(userId: String): Flow<Boolean> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val user = auth.currentUser
        val isBootstrapEmail = user != null &&
            user.uid == userId &&
            user.isEmailVerified &&
            user.email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)

        val adminDocFlow = db.collection("admins").document(userId)
            .snapshots()
            .map { it.exists() }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                if (auth.currentUser?.uid == userId) {
                    handleFirestoreError(root, OperationType.GET, "admins/$userId")
                }
                emit(false)
            }

        emitAll(
            adminDocFlow.map { inAdminRegistry ->
                isBootstrapEmail || inAdminRegistry
            }
        )
    }

    suspend fun updatePreferences(
        userId: String,
        spamProtectionEnabled: Boolean,
        autoBlockHighRisk: Boolean,
        notificationsEnabled: Boolean,
        themeMode: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            ensureProfileExistsBeforeUpdate(uid)
            val safeTheme = if (themeMode in listOf("SYSTEM", "LIGHT", "DARK")) themeMode else "SYSTEM"
            db.collection("users").document(uid).update(
                mapOf(
                    "spamProtectionEnabled" to spamProtectionEnabled,
                    "autoBlockHighRisk" to autoBlockHighRisk,
                    "notificationsEnabled" to notificationsEnabled,
                    "themeMode" to safeTheme,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfileDetails(
        userId: String,
        displayName: String,
        phoneNumber: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            ensureProfileExistsBeforeUpdate(uid)
            val cleanName = displayName.trim().take(80)
            require(cleanName.isNotEmpty()) { "Display name cannot be empty" }
            val cleanPhone = phoneNumber.trim().take(24)
            db.collection("users").document(uid).update(
                mapOf(
                    "displayName" to cleanName,
                    "phoneNumber" to cleanPhone,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeBlockedNumbers(userId: String): Flow<List<BlockedNumber>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/blocked_numbers"
        emitAll(
            db.collection("users").document(userId).collection("blocked_numbers")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(BlockedNumber::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun blockNumber(
        userId: String,
        rawNumber: String,
        label: String,
        reason: String,
        blockMode: String = "REJECT"
    ): Result<Unit> {
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        val path = "users/$userId/blocked_numbers/$numberKey"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            require(numberKey.length in 3..24) { "Enter a valid phone number (at least 3 digits)." }
            val formatted = PhoneNumberNormalizer.formatDisplay(rawNumber).take(30)
            val safeMode = if (blockMode in listOf("REJECT", "SILENCE")) blockMode else "REJECT"
            val docRef = db.collection("users").document(uid)
                .collection("blocked_numbers").document(numberKey)
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(
                    mapOf(
                        "label" to label.trim().take(80),
                        "reason" to reason.trim().take(160),
                        "blockMode" to safeMode,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "phoneNumber" to numberKey,
                        "rawNumber" to formatted,
                        "label" to label.trim().take(80),
                        "reason" to reason.trim().take(160),
                        "blockMode" to safeMode,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun unblockNumber(userId: String, blockId: String): Result<Unit> {
        val path = "users/$userId/blocked_numbers/$blockId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            require(blockId.isNotBlank()) { "Block ID must not be blank" }
            db.collection("users").document(uid)
                .collection("blocked_numbers").document(blockId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun updateBlockMode(userId: String, blockId: String, blockMode: String): Result<Unit> {
        val path = "users/$userId/blocked_numbers/$blockId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            val safeMode = if (blockMode in listOf("REJECT", "SILENCE")) blockMode else "REJECT"
            db.collection("users").document(uid)
                .collection("blocked_numbers").document(blockId)
                .update(
                    mapOf(
                        "blockMode" to safeMode,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeCallEvents(userId: String): Flow<List<CallEvent>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/call_events"
        emitAll(
            db.collection("users").document(userId).collection("call_events")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CallEvent::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.occurredAtMillis }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun recordCallEvent(
        userId: String,
        phoneNumber: String,
        callerName: String,
        callDirection: String,
        actionTaken: String,
        spamScore: Int,
        stirVerification: String,
        durationSeconds: Long = 0L,
        occurredAtMillis: Long = System.currentTimeMillis()
    ): Result<Unit> {
        val path = "users/$userId/call_events"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            ensureProfileExistsBeforeUpdate(uid)
            val formatted = PhoneNumberNormalizer.formatDisplay(phoneNumber).take(30)
            require(formatted.length >= 3) { "Phone number too short" }
            val safeDirection = if (callDirection in listOf("INCOMING", "OUTGOING", "MISSED", "BLOCKED")) {
                callDirection
            } else {
                "INCOMING"
            }
            val safeAction = if (actionTaken in listOf("ALLOWED", "BLOCKED", "SILENCED")) {
                actionTaken
            } else {
                "ALLOWED"
            }
            val safeStir = if (stirVerification in listOf("PASSED", "FAILED", "NOT_VERIFIED")) {
                stirVerification
            } else {
                "NOT_VERIFIED"
            }
            val safeScore = spamScore.coerceIn(0, 100).toLong()

            val docRef = db.collection("users").document(uid).collection("call_events").document()
            docRef.set(
                mapOf(
                    "userId" to uid,
                    "phoneNumber" to formatted,
                    "callerName" to callerName.trim().take(80),
                    "callDirection" to safeDirection,
                    "actionTaken" to safeAction,
                    "spamScore" to safeScore,
                    "stirVerification" to safeStir,
                    "durationSeconds" to durationSeconds.coerceIn(0L, 86400L),
                    "occurredAtMillis" to occurredAtMillis.coerceAtLeast(0L),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val userUpdates = mutableMapOf<String, Any>(
                "totalCallsScreened" to FieldValue.increment(1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (safeAction == "BLOCKED") {
                userUpdates["totalSpamBlocked"] = FieldValue.increment(1L)
            }
            db.collection("users").document(uid).update(userUpdates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCallEvent(userId: String, eventId: String): Result<Unit> {
        val path = "users/$userId/call_events/$eventId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed" }
            db.collection("users").document(uid)
                .collection("call_events").document(eventId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeSystemAlerts(userId: String): Flow<List<SystemAlert>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "system_alerts"
        emitAll(
            db.collection("system_alerts")
                .whereEqualTo("targetScope", "ALL_USERS")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(SystemAlert::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val root = unwrapFirestoreError(error)
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(root, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    companion object {
        const val BOOTSTRAP_ADMIN_EMAIL = "ubongn59@gmail.com"
    }
}
