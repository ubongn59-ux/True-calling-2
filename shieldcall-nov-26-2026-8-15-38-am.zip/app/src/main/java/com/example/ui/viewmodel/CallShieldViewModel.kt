package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BlockedNumber
import com.example.data.model.CallEvent
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.CallerLookupResult
import com.example.data.model.CallerRating
import com.example.data.model.DeviceCallLogItem
import com.example.data.model.DeviceContactItem
import com.example.data.model.SpamReport
import com.example.data.model.SystemAlert
import com.example.data.model.UiState
import com.example.data.model.UnifiedCallRecord
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedBusiness
import com.example.data.repository.DirectoryAdminRepository
import com.example.data.repository.UserProtectionRepository
import com.example.service.DeviceContentReader
import com.example.ui.theme.ThemeMode
import com.example.util.PhoneNumberNormalizer
import com.example.util.ScreeningCache
import com.example.util.unwrapFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CallShieldViewModel(
    private val currentUserId: String,
    private val userRepo: UserProtectionRepository,
    private val directoryRepo: DirectoryAdminRepository,
    private val screeningCache: ScreeningCache
) : ViewModel() {

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents = _snackbarEvents.asSharedFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _deviceCallLogs = MutableStateFlow<List<DeviceCallLogItem>>(emptyList())
    val deviceCallLogs: StateFlow<List<DeviceCallLogItem>> = _deviceCallLogs.asStateFlow()

    private val _deviceContacts = MutableStateFlow<List<DeviceContactItem>>(emptyList())
    val deviceContacts: StateFlow<List<DeviceContactItem>> = _deviceContacts.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _inspectedNumber = MutableStateFlow<String?>(null)
    val inspectedNumber: StateFlow<String?> = _inspectedNumber.asStateFlow()

    private val _onlineLookupEntry = MutableStateFlow<CallerDirectoryEntry?>(null)

    val userProfileState: StateFlow<UiState<UserProfile?>> = userRepo.observeUserProfile(currentUserId)
        .onEach { profile ->
            if (profile != null) {
                screeningCache.spamProtectionEnabled = profile.spamProtectionEnabled
                screeningCache.autoBlockHighRisk = profile.autoBlockHighRisk
                screeningCache.notificationsEnabled = profile.notificationsEnabled
            }
        }
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing user profile", root)
            emit(UiState.Error(root.message ?: "Failed to load profile"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val themeMode: StateFlow<ThemeMode> = userProfileState
        .map { state ->
            when (state) {
                is UiState.Success -> ThemeMode.fromRaw(state.data?.themeMode)
                else -> ThemeMode.SYSTEM
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ThemeMode.SYSTEM)

    val isAdmin: StateFlow<Boolean> = userRepo.observeIsAdmin(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing admin status", root)
            emit(false)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), false)

    val blockedNumbersState: StateFlow<UiState<List<BlockedNumber>>> = userRepo.observeBlockedNumbers(currentUserId)
        .onEach { items -> screeningCache.syncBlockedNumbers(items) }
        .map<List<BlockedNumber>, UiState<List<BlockedNumber>>> { UiState.Success(it) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing blocked numbers", root)
            emit(UiState.Error(root.message ?: "Failed to load blocklist"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val callEvents: StateFlow<List<CallEvent>> = userRepo.observeCallEvents(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing call events", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val publicDirectory: StateFlow<List<CallerDirectoryEntry>> = directoryRepo.observePublicDirectory(currentUserId)
        .onEach { entries -> screeningCache.syncDirectoryEntries(entries) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing directory", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val verifiedBusinesses: StateFlow<List<VerifiedBusiness>> = directoryRepo.observeVerifiedBusinesses(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing verified businesses", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val myBusinessApplications: StateFlow<List<VerifiedBusiness>> = directoryRepo.observeMyBusinessApplications(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing business applications", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val mySpamReports: StateFlow<List<SpamReport>> = directoryRepo.observeMySpamReports(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing user spam reports", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val systemAlerts: StateFlow<List<SystemAlert>> = userRepo.observeSystemAlerts(currentUserId)
        .catch { error ->
            val root = unwrapFirestoreError(error)
            Log.w(TAG, "Error observing system alerts", root)
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    private val inspectedKeyFlow: StateFlow<String?> = _inspectedNumber
        .map { raw -> raw?.let { PhoneNumberNormalizer.toKey(it) }?.takeIf { it.length >= 3 } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val inspectedRatings: StateFlow<List<CallerRating>> = inspectedKeyFlow
        .flatMapLatest { key ->
            if (key == null) flowOf(emptyList())
            else directoryRepo.observeRatingsForNumber(currentUserId, key)
                .catch { error ->
                    unwrapFirestoreError(error)
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val inspectedApprovedReports: StateFlow<List<SpamReport>> = inspectedKeyFlow
        .flatMapLatest { key ->
            if (key == null) flowOf(emptyList())
            else directoryRepo.observeApprovedReportsForNumber(currentUserId, key)
                .catch { error ->
                    unwrapFirestoreError(error)
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val inspectedLookupResult: StateFlow<CallerLookupResult?> = combine(
        _inspectedNumber,
        publicDirectory,
        _deviceContacts,
        blockedNumbersState,
        inspectedRatings,
        inspectedApprovedReports,
        _onlineLookupEntry
    ) { values ->
        val raw = values[0] as? String ?: return@combine null
        @Suppress("UNCHECKED_CAST")
        val directory = values[1] as List<CallerDirectoryEntry>
        @Suppress("UNCHECKED_CAST")
        val contacts = values[2] as List<DeviceContactItem>
        @Suppress("UNCHECKED_CAST")
        val blockedState = values[3] as UiState<List<BlockedNumber>>
        @Suppress("UNCHECKED_CAST")
        val ratings = values[4] as List<CallerRating>
        @Suppress("UNCHECKED_CAST")
        val reports = values[5] as List<SpamReport>
        val onlineEntry = values[6] as? CallerDirectoryEntry

        val key = PhoneNumberNormalizer.toKey(raw)
        if (key.length < 3) return@combine null
        val display = PhoneNumberNormalizer.formatDisplay(raw)
        val dirEntry = directory.firstOrNull { it.numberKey == key }
            ?: onlineEntry?.takeIf { it.numberKey == key }
        val contact = contacts.firstOrNull { it.numberKey == key }
        val blocked = (blockedState as? UiState.Success)?.data?.firstOrNull { it.phoneNumber == key }
        val resolvedName = contact?.name
            ?: dirEntry?.callerName
            ?: blocked?.label?.takeIf { it.isNotBlank() }
            ?: display

        CallerLookupResult(
            numberKey = key,
            displayNumber = display,
            resolvedName = resolvedName,
            directoryEntry = dirEntry,
            matchedContact = contact,
            blockedEntry = blocked,
            ratings = ratings,
            approvedReports = reports
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val unifiedCalls: StateFlow<List<UnifiedCallRecord>> = combine(
        _deviceCallLogs,
        callEvents,
        publicDirectory,
        _deviceContacts,
        blockedNumbersState
    ) { deviceLogs, cloudEvents, directory, contacts, blockedState ->
        val dirByKey = directory.associateBy { it.numberKey }
        val contactsByKey = contacts.associateBy { it.numberKey }
        val blockedByKey = (blockedState as? UiState.Success)?.data?.associateBy { it.phoneNumber }.orEmpty()

        val cloudRecords = cloudEvents.map { evt ->
            val key = PhoneNumberNormalizer.toKey(evt.phoneNumber)
            val dir = dirByKey[key]
            val contact = contactsByKey[key]
            val blocked = blockedByKey[key]
            UnifiedCallRecord(
                id = "cloud_${evt.id}",
                rawNumber = evt.phoneNumber,
                numberKey = key,
                displayName = contact?.name
                    ?: dir?.callerName
                    ?: evt.callerName.ifBlank { evt.phoneNumber },
                direction = evt.callDirection,
                actionTaken = evt.actionTaken,
                spamScore = maxOf(evt.spamScore.toInt(), dir?.spamScore?.toInt() ?: 0),
                verifiedBusiness = dir?.verifiedBusiness == true,
                category = dir?.category ?: if (evt.spamScore >= 50) "SCAM_FRAUD" else "COMMUNITY",
                stirVerification = evt.stirVerification,
                isBlocked = blocked != null || evt.actionTaken == "BLOCKED",
                isContact = contact != null,
                timestampMillis = evt.occurredAtMillis,
                durationSeconds = evt.durationSeconds,
                isCloudEvent = true
            )
        }

        val deviceRecords = deviceLogs.map { log ->
            val dir = dirByKey[log.numberKey]
            val contact = contactsByKey[log.numberKey]
            val blocked = blockedByKey[log.numberKey]
            val isBlocked = blocked != null || log.callType == "BLOCKED"
            UnifiedCallRecord(
                id = "dev_${log.id}",
                rawNumber = log.phoneNumber,
                numberKey = log.numberKey,
                displayName = contact?.name
                    ?: log.cachedContactName?.takeIf { it.isNotBlank() }
                    ?: dir?.callerName
                    ?: log.phoneNumber,
                direction = log.callType,
                actionTaken = if (isBlocked) "BLOCKED" else "ALLOWED",
                spamScore = if (blocked != null) 100 else dir?.spamScore?.toInt() ?: 0,
                verifiedBusiness = dir?.verifiedBusiness == true,
                category = dir?.category ?: if (contact != null) "CONTACT" else "UNKNOWN",
                stirVerification = "NOT_VERIFIED",
                isBlocked = isBlocked,
                isContact = contact != null,
                timestampMillis = log.timestampMillis,
                durationSeconds = log.durationSeconds,
                isCloudEvent = false
            )
        }

        (cloudRecords + deviceRecords).sortedByDescending { it.timestampMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    private val syncMutex = kotlinx.coroutines.sync.Mutex()
    private var profileEnsured = false

    init {
        viewModelScope.launch {
            ensureProfileAndSyncPending()
        }
    }

    fun refreshDeviceData(context: Context) {
        viewModelScope.launch {
            _deviceCallLogs.value = DeviceContentReader.readDeviceCallLogs(context)
            _deviceContacts.value = DeviceContentReader.readDeviceContacts(context)
            ensureProfileAndSyncPending()
        }
    }

    private suspend fun ensureProfileAndSyncPending() {
        syncMutex.lock()
        try {
            if (!profileEnsured) {
                val user = Firebase.auth.currentUser
                if (user != null && user.uid == currentUserId) {
                    val res = userRepo.ensureUserProfile(user)
                    if (res.isSuccess) {
                        profileEnsured = true
                    } else {
                        _snackbarEvents.tryEmit(
                            res.exceptionOrNull()?.message ?: "Could not sync user profile"
                        )
                    }
                }
            }
            if (profileEnsured) {
                val pending = screeningCache.drainPendingScreenedEvents()
                pending.forEach { evt ->
                    userRepo.recordCallEvent(
                        userId = currentUserId,
                        phoneNumber = evt.phoneNumber,
                        callerName = evt.callerName,
                        callDirection = if (evt.actionTaken == "BLOCKED") "BLOCKED" else "INCOMING",
                        actionTaken = evt.actionTaken,
                        spamScore = evt.spamScore,
                        stirVerification = evt.stirVerification,
                        occurredAtMillis = evt.occurredAtMillis
                    )
                }
            }
        } finally {
            syncMutex.unlock()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun inspectNumber(rawNumber: String) {
        _inspectedNumber.value = rawNumber
        val key = PhoneNumberNormalizer.toKey(rawNumber)
        if (key.length >= 3) {
            viewModelScope.launch {
                val res = directoryRepo.getDirectoryEntry(key)
                _onlineLookupEntry.value = res.getOrNull()
            }
        }
    }

    fun dismissInspector() {
        _inspectedNumber.value = null
        _onlineLookupEntry.value = null
    }

    fun updatePreferences(
        spamProtectionEnabled: Boolean,
        autoBlockHighRisk: Boolean,
        notificationsEnabled: Boolean,
        themeMode: ThemeMode
    ) {
        screeningCache.spamProtectionEnabled = spamProtectionEnabled
        screeningCache.autoBlockHighRisk = autoBlockHighRisk
        screeningCache.notificationsEnabled = notificationsEnabled
        viewModelScope.launch {
            val res = userRepo.updatePreferences(
                userId = currentUserId,
                spamProtectionEnabled = spamProtectionEnabled,
                autoBlockHighRisk = autoBlockHighRisk,
                notificationsEnabled = notificationsEnabled,
                themeMode = themeMode.name
            )
            if (res.isFailure) {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Failed to update settings")
            }
        }
    }

    fun updateProfileDetails(displayName: String, phoneNumber: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = userRepo.updateProfileDetails(currentUserId, displayName, phoneNumber)
            _isBusy.value = false
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Profile updated")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Could not update profile")
            }
        }
    }

    fun blockNumber(rawNumber: String, label: String, reason: String, blockMode: String = "REJECT") {
        viewModelScope.launch {
            _isBusy.value = true
            val res = userRepo.blockNumber(currentUserId, rawNumber, label, reason, blockMode)
            _isBusy.value = false
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Number added to blocklist")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Failed to block number")
            }
        }
    }

    fun unblockNumber(blockId: String) {
        viewModelScope.launch {
            val res = userRepo.unblockNumber(currentUserId, blockId)
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Number unblocked")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Failed to unblock number")
            }
        }
    }

    fun toggleBlockMode(item: BlockedNumber) {
        val nextMode = if (item.blockMode == "REJECT") "SILENCE" else "REJECT"
        viewModelScope.launch {
            val res = userRepo.updateBlockMode(currentUserId, item.id, nextMode)
            if (res.isFailure) {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Could not change block mode")
            }
        }
    }

    fun submitSpamReport(
        rawNumber: String,
        reportedName: String,
        category: String,
        comment: String
    ) {
        val reporterName = (userProfileState.value as? UiState.Success)?.data?.displayName ?: "Community Member"
        viewModelScope.launch {
            _isBusy.value = true
            val res = directoryRepo.submitSpamReport(
                reporterName = reporterName,
                rawNumber = rawNumber,
                reportedName = reportedName,
                category = category,
                comment = comment
            )
            _isBusy.value = false
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Report submitted to CallShield community")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Could not submit report")
            }
        }
    }

    fun submitCallerRating(rawNumber: String, stars: Int, review: String) {
        val userName = (userProfileState.value as? UiState.Success)?.data?.displayName ?: "Community Member"
        viewModelScope.launch {
            _isBusy.value = true
            val res = directoryRepo.submitCallerRating(
                userName = userName,
                rawNumber = rawNumber,
                stars = stars,
                review = review
            )
            _isBusy.value = false
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Rating saved")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Could not save rating")
            }
        }
    }

    fun submitBusinessVerification(
        businessName: String,
        rawNumber: String,
        category: String,
        website: String,
        description: String
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = directoryRepo.submitBusinessVerification(
                businessName = businessName,
                rawNumber = rawNumber,
                category = category,
                website = website,
                description = description
            )
            _isBusy.value = false
            if (res.isSuccess) {
                _snackbarEvents.tryEmit("Verification request submitted for review")
            } else {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Failed to submit application")
            }
        }
    }

    fun deleteCloudCallEvent(cloudRecordId: String) {
        val docId = cloudRecordId.removePrefix("cloud_")
        viewModelScope.launch {
            val res = userRepo.deleteCallEvent(currentUserId, docId)
            if (res.isFailure) {
                _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Failed to remove event")
            }
        }
    }

    private companion object {
        const val TAG = "CallShieldVM"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
