package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.BlockedNumber
import com.example.data.model.SpamReport
import com.example.data.model.SystemAlert
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedBusiness
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SystemAlertBanner
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ThemeMode

@Composable
fun ShieldScreen(
    profile: UserProfile?,
    isAdmin: Boolean,
    isGuestMode: Boolean = false,
    blockedNumbers: List<BlockedNumber>,
    myReports: List<SpamReport>,
    myBusinessApplications: List<VerifiedBusiness>,
    systemAlerts: List<SystemAlert>,
    themeMode: ThemeMode,
    hasCallScreeningRole: Boolean,
    onRequestCallScreeningRole: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onUpdatePreferences: (Boolean, Boolean, Boolean, ThemeMode) -> Unit,
    onUpdateProfile: (String, String) -> Unit,
    onBlockNumber: (String, String, String, String) -> Unit,
    onUnblockNumber: (String) -> Unit,
    onToggleBlockMode: (BlockedNumber) -> Unit,
    onSubmitBusinessVerification: (String, String, String, String, String) -> Unit,
    onSignInWithGoogle: () -> Unit = {},
    onSignOut: () -> Unit
) {
    var showAddBlockDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showBusinessApplyDialog by remember { mutableStateOf(false) }

    val protectionEnabled = profile?.spamProtectionEnabled ?: true
    val autoBlockHighRisk = profile?.autoBlockHighRisk ?: true
    val notificationsEnabled = profile?.notificationsEnabled ?: true

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Account Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (!isGuestMode && !profile?.photoUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = profile.photoUrl,
                                    contentDescription = stringResource(R.string.cd_user_avatar),
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                )
                            } else {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(54.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.Person,
                                            contentDescription = stringResource(R.string.cd_user_avatar),
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = if (isGuestMode) {
                                            stringResource(R.string.guest_mode_label)
                                        } else {
                                            profile?.displayName ?: "CallShield User"
                                        },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        shape = CircleShape,
                                        color = when {
                                            isGuestMode -> MaterialTheme.colorScheme.secondaryContainer
                                            isAdmin -> MaterialTheme.colorScheme.tertiaryContainer
                                            else -> MaterialTheme.colorScheme.secondaryContainer
                                        }
                                    ) {
                                        Text(
                                            text = when {
                                                isGuestMode -> "GUEST"
                                                isAdmin -> "ADMIN"
                                                else -> "PROTECTED"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isAdmin && !isGuestMode) {
                                                MaterialTheme.colorScheme.onTertiaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onSecondaryContainer
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                val emailText = profile?.email.orEmpty()
                                if (emailText.isNotBlank()) {
                                    Text(
                                        text = emailText,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                val phoneText = profile?.phoneNumber.orEmpty()
                                if (!isGuestMode && phoneText.isNotBlank()) {
                                    Text(
                                        text = phoneText,
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (!isGuestMode) {
                                IconButton(
                                    onClick = { showEditProfileDialog = true },
                                    modifier = Modifier.testTag("edit_profile_button")
                                ) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Edit profile")
                                }
                            }
                        }

                        if (isGuestMode) {
                            Button(
                                onClick = onSignInWithGoogle,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("guest_upgrade_google_button")
                            ) {
                                Text("Sign in with Google to Sync & Unlock Cloud Features")
                            }
                        }
                    }
                }
            }

            // 2. Protection & Appearance Controls
            item {
                SectionHeader(title = "Protection & Appearance")
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingSwitchRow(
                            title = "Real-Time Spam Shield",
                            subtitle = "Screen incoming calls against community risk scores & blocklists",
                            checked = protectionEnabled,
                            testTag = "switch_spam_protection",
                            onCheckedChange = { enabled ->
                                onUpdatePreferences(enabled, autoBlockHighRisk, notificationsEnabled, themeMode)
                            }
                        )
                        SettingSwitchRow(
                            title = "Auto-Block High Risk (75%+)",
                            subtitle = "Automatically reject robocalls, scams, and STIR/SHAKEN failures",
                            checked = autoBlockHighRisk,
                            testTag = "switch_auto_block",
                            onCheckedChange = { auto ->
                                onUpdatePreferences(protectionEnabled, auto, notificationsEnabled, themeMode)
                            }
                        )
                        SettingSwitchRow(
                            title = "Caller ID & Alert Notifications",
                            subtitle = "Notify on identified callers and blocked spam calls",
                            checked = notificationsEnabled,
                            testTag = "switch_notifications",
                            onCheckedChange = { notify ->
                                if (notify) onRequestNotificationPermission()
                                onUpdatePreferences(protectionEnabled, autoBlockHighRisk, notify, themeMode)
                            }
                        )

                        if (!hasCallScreeningRole) {
                            OutlinedButton(
                                onClick = onRequestCallScreeningRole,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("shield_enable_role_button")
                            ) {
                                Icon(Icons.Filled.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.enable_call_screening))
                            }
                        }

                        Text("App Theme", style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = themeMode == mode,
                                    onClick = {
                                        onUpdatePreferences(protectionEnabled, autoBlockHighRisk, notificationsEnabled, mode)
                                    },
                                    label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                                    modifier = Modifier.testTag("theme_chip_${mode.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }

            // 3. Personal Blocklist
            item {
                SectionHeader(
                    title = "Personal Blocklist (${blockedNumbers.size})",
                    actionLabel = "Add Number",
                    onAction = { showAddBlockDialog = true }
                )
            }
            if (blockedNumbers.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "No Blocked Numbers Yet",
                        subtitle = "Add persistent spam numbers or block callers directly from your call log.",
                        ctaLabel = "Block a Number",
                        onCta = { showAddBlockDialog = true },
                        showIllustration = false
                    )
                }
            } else {
                items(blockedNumbers, key = { it.id }) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.label.ifBlank { item.rawNumber },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${item.rawNumber} • ${item.reason.ifBlank { "Blocked" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            FilterChip(
                                selected = item.blockMode == "REJECT",
                                onClick = { onToggleBlockMode(item) },
                                label = { Text(item.blockMode) }
                            )
                            IconButton(
                                onClick = { onUnblockNumber(item.id) },
                                modifier = Modifier.testTag("unblock_${item.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Unblock ${item.rawNumber}",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // 4. Verified Business Verification Portal
            item {
                SectionHeader(
                    title = "Verified Business Identity",
                    actionLabel = "Apply",
                    onAction = {
                        if (isGuestMode) {
                            onSubmitBusinessVerification("", "", "", "", "")
                        } else {
                            showBusinessApplyDialog = true
                        }
                    }
                )
            }
            if (myBusinessApplications.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Business,
                                contentDescription = "Business verification",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Register Your Business Line",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isGuestMode) {
                                        "Sign in with Google to apply for a Verified Business badge."
                                    } else {
                                        "Display a Verified Business badge when calling customers."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = {
                                    if (isGuestMode) {
                                        onSubmitBusinessVerification("", "", "", "", "")
                                    } else {
                                        showBusinessApplyDialog = true
                                    }
                                },
                                modifier = Modifier.testTag("apply_verified_business_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Apply")
                            }
                        }
                    }
                }
            } else {
                items(myBusinessApplications, key = { it.id }) { app ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.businessName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text("${app.displayNumber} • ${app.category}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(
                                text = app.verificationStatus,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = when (app.verificationStatus) {
                                    "VERIFIED" -> MaterialTheme.colorScheme.tertiary
                                    "REJECTED" -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            )
                        }
                    }
                }
            }

            // 5. Security Alerts & My Reports
            if (systemAlerts.isNotEmpty()) {
                item {
                    SectionHeader(title = "Live Security Alerts (${systemAlerts.size})")
                }
                items(systemAlerts, key = { "shield_alert_${it.id}" }) { alert ->
                    SystemAlertBanner(alert = alert)
                }
            }

            if (myReports.isNotEmpty()) {
                item {
                    SectionHeader(title = "My Spam Reports (${myReports.size})")
                }
                items(myReports.take(10), key = { it.id }) { report ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = report.reportedName.ifBlank { report.displayNumber },
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "${report.displayNumber} • ${report.category}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = report.status,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // 6. Sign Out / Exit Guest Mode
            item {
                OutlinedButton(
                    onClick = onSignOut,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign out")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (isGuestMode) stringResource(R.string.exit_guest_mode)
                        else stringResource(R.string.sign_out)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (showAddBlockDialog) {
        BlockNumberDialog(
            onDismiss = { showAddBlockDialog = false },
            onConfirm = { num, label, reason, mode ->
                onBlockNumber(num, label, reason, mode)
                showAddBlockDialog = false
            }
        )
    }

    if (showEditProfileDialog) {
        EditProfileDialog(
            initialName = profile?.displayName.orEmpty(),
            initialPhone = profile?.phoneNumber.orEmpty(),
            onDismiss = { showEditProfileDialog = false },
            onSave = { name, phone ->
                onUpdateProfile(name, phone)
                showEditProfileDialog = false
            }
        )
    }

    if (showBusinessApplyDialog) {
        ApplyBusinessDialog(
            onDismiss = { showBusinessApplyDialog = false },
            onSubmit = { name, num, cat, web, desc ->
                onSubmitBusinessVerification(name, num, cat, web, desc)
                showBusinessApplyDialog = false
            }
        )
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun EditProfileDialog(
    initialName: String,
    initialPhone: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf(initialPhone) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 80) name = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { if (it.length <= 24) phone = it },
                    label = { Text("Your Phone Number (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, phone) },
                enabled = name.trim().isNotEmpty()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ApplyBusinessDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Customer Support") }
    var website by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Apply for Verified Business") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 80) name = it },
                    label = { Text("Business Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Business Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { if (it.length <= 40) category = it },
                    label = { Text("Category (e.g. Banking, Delivery)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = website,
                    onValueChange = { if (it.length <= 120) website = it },
                    label = { Text("Website (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { if (it.length <= 300) description = it },
                    label = { Text("Description") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(name, number, category, website, description) },
                enabled = name.trim().length >= 2 && number.filter { it.isDigit() }.length >= 3
            ) {
                Text("Submit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
