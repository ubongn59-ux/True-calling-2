package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminMember
import com.example.data.model.SpamReport
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedBusiness
import com.example.data.repository.DirectoryAdminRepository
import com.example.util.unwrapFirestoreError
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdminViewModel(
    private val currentUserId: String,
    private val directoryRepo: DirectoryAdminRepository
) : ViewModel() {

    private val _adminFeedback = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val adminFeedback = _adminFeedback.asSharedFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    val pendingReportsState: StateFlow<UiState<List<SpamReport>>> =
        directoryRepo.observePendingReportsAdmin(currentUserId)
            .map<List<SpamReport>, UiState<List<SpamReport>>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(TAG, "Error observing pending reports", root)
                emit(UiState.Error(root.message ?: "Unable to load moderation queue"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val pendingBusinessesState: StateFlow<UiState<List<VerifiedBusiness>>> =
        directoryRepo.observePendingBusinessesAdmin(currentUserId)
            .map<List<VerifiedBusiness>, UiState<List<VerifiedBusiness>>> { UiState.Success(it) }
            .catch { error ->
                val root = unwrapFirestoreError(error)
                Log.w(TAG, "Error observing pending businesses", root)
                emit(UiState.Error(root.message ?: "Unable to load business queue"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val allUsers: StateFlow<List<UserProfile>> =
        directoryRepo.observeAllUsersAdmin(currentUserId)
            .catch { error ->
                unwrapFirestoreError(error)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val adminsList: StateFlow<List<AdminMember>> =
        directoryRepo.observeAdminsList(currentUserId)
            .catch { error ->
                unwrapFirestoreError(error)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    fun moderateReport(report: SpamReport, approve: Boolean) {
        viewModelScope.launch {
            _isProcessing.value = true
            val res = directoryRepo.moderateReport(report, approve)
            _isProcessing.value = false
            if (res.isSuccess) {
                _adminFeedback.tryEmit(if (approve) "Report approved" else "Report rejected")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Moderation action failed")
            }
        }
    }

    fun moderateBusiness(business: VerifiedBusiness, approve: Boolean) {
        viewModelScope.launch {
            _isProcessing.value = true
            val res = directoryRepo.moderateBusiness(business, approve)
            _isProcessing.value = false
            if (res.isSuccess) {
                _adminFeedback.tryEmit(if (approve) "${business.businessName} verified" else "Application rejected")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Verification update failed")
            }
        }
    }

    fun upsertDirectoryEntry(
        rawNumber: String,
        callerName: String,
        category: String,
        spamScore: Int,
        verifiedBusiness: Boolean,
        visibility: String
    ) {
        viewModelScope.launch {
            _isProcessing.value = true
            val res = directoryRepo.adminUpsertDirectoryEntry(
                rawNumber = rawNumber,
                callerName = callerName,
                category = category,
                spamScore = spamScore,
                verifiedBusiness = verifiedBusiness,
                visibility = visibility
            )
            _isProcessing.value = false
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Directory entry saved")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to save directory entry")
            }
        }
    }

    fun deleteDirectoryEntry(numberKey: String) {
        viewModelScope.launch {
            val res = directoryRepo.adminDeleteDirectoryEntry(numberKey)
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Directory entry deleted")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to delete entry")
            }
        }
    }

    fun publishAlert(title: String, message: String, severity: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val res = directoryRepo.publishSystemAlert(title, message, severity)
            _isProcessing.value = false
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Alert broadcast to all users")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to publish alert")
            }
        }
    }

    fun deleteAlert(alertId: String) {
        viewModelScope.launch {
            val res = directoryRepo.deleteSystemAlert(alertId)
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Alert removed")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to remove alert")
            }
        }
    }

    fun grantAdmin(uid: String, email: String, displayName: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val res = directoryRepo.grantAdminRole(uid, email, displayName)
            _isProcessing.value = false
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Admin access granted")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to grant admin role")
            }
        }
    }

    fun revokeAdmin(uid: String) {
        viewModelScope.launch {
            val res = directoryRepo.revokeAdminRole(uid)
            if (res.isSuccess) {
                _adminFeedback.tryEmit("Admin access revoked")
            } else {
                _adminFeedback.tryEmit(res.exceptionOrNull()?.message ?: "Failed to revoke admin role")
            }
        }
    }

    private companion object {
        const val TAG = "AdminVM"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
