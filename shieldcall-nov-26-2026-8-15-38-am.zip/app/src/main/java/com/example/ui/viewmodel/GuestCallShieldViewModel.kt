package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BlockedNumber
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.CallerLookupResult
import com.example.data.model.DeviceCallLogItem
import com.example.data.model.DeviceContactItem
import com.example.data.model.UnifiedCallRecord
import com.example.data.model.UserProfile
import com.example.service.DeviceContentReader
import com.example.ui.theme.ThemeMode
import com.example.util.PendingScreenedEvent
import com.example.util.PhoneNumberNormalizer
import com.example.util.ScreeningCache
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GuestCallShieldViewModel(
    private val screeningCache: ScreeningCache
) : ViewModel() {

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents = _snackbarEvents.asSharedFlow()

    private val _signInPromptEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val signInPromptEvents = _signInPromptEvents.asSharedFlow()

    private val _deviceCallLogs = MutableStateFlow<List<DeviceCallLogItem>>(emptyList())
    private val _deviceContacts = MutableStateFlow<List<DeviceContactItem>>(emptyList())
    val deviceContacts: StateFlow<List<DeviceContactItem>> = _deviceContacts.asStateFlow()

    private val _localScreenedEvents = MutableStateFlow<List<PendingScreenedEvent>>(
        screeningCache.peekPendingScreenedEvents()
    )

    private val _blockedNumbers = MutableStateFlow(screeningCache.getBlockedNumbersList())
    val blockedNumbers: StateFlow<List<BlockedNumber>> = _blockedNumbers.asStateFlow()

    private val _cachedDirectory = MutableStateFlow(screeningCache.getCachedDirectoryEntries())
    val cachedDirectory: StateFlow<List<CallerDirectoryEntry>> = _cachedDirectory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _inspectedNumber = MutableStateFlow<String?>(null)

    private val _themeMode = MutableStateFlow(ThemeMode.fromRaw(screeningCache.guestThemeMode))
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _guestProfile = MutableStateFlow(buildGuestProfile())
    val guestProfile: StateFlow<UserProfile> = _guestProfile.asStateFlow()

    private fun buildGuestProfile(): UserProfile {
        val events = screeningCache.peekPendingScreenedEvents()
        val blockedCount = events.count { it.actionTaken == "BLOCKED" }.toLong()
        return UserProfile(
            id = "guest",
            userId = "guest",
            displayName = "Guest User",
            email = "On-device protection active",
            role = "GUEST",
            spamProtectionEnabled = screeningCache.spamProtectionEnabled,
            autoBlockHighRisk = screeningCache.autoBlockHighRisk,
            notificationsEnabled = screeningCache.notificationsEnabled,
            themeMode = screeningCache.guestThemeMode,
            totalCallsScreened = events.size.toLong(),
            totalSpamBlocked = blockedCount
        )
    }

    val inspectedLookupResult: StateFlow<CallerLookupResult?> = combine(
        _inspectedNumber,
        _cachedDirectory,
        _deviceContacts,
        _blockedNumbers
    ) { raw, directory, contacts, blockedList ->
        if (raw == null) return@combine null
        val key = PhoneNumberNormalizer.toKey(raw)
        if (key.length < 3) return@combine null
        val display = PhoneNumberNormalizer.formatDisplay(raw)
        val dirEntry = directory.firstOrNull { it.numberKey == key }
        val contact = contacts.firstOrNull { it.numberKey == key }
        val blocked = blockedList.firstOrNull { it.phoneNumber == key }
        val resolvedName = contact?.name
            ?: dirEntry?.callerName
            ?: blocked?.label?.takeIf { it.isNotBlank() }
            ?: display

        CallerLookupResult(
            numberKey = key,
            displayNumber = display,
            resolvedName = resolvedName,
            directoryEntry = dirEntry,
            matchedContact = contact,
            blockedEntry = blocked,
            ratings = emptyList(),
            approvedReports = emptyList()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val unifiedCalls: StateFlow<List<UnifiedCallRecord>> = combine(
        _deviceCallLogs,
        _localScreenedEvents,
        _cachedDirectory,
        _deviceContacts,
        _blockedNumbers
    ) { deviceLogs, screenedEvents, directory, contacts, blockedList ->
        val dirByKey = directory.associateBy { it.numberKey }
        val contactsByKey = contacts.associateBy { it.numberKey }
        val blockedByKey = blockedList.associateBy { it.phoneNumber }

        val localScreenedRecords = screenedEvents.mapIndexed { index, evt ->
            val key = PhoneNumberNormalizer.toKey(evt.phoneNumber)
            val dir = dirByKey[key]
            val contact = contactsByKey[key]
            val blocked = blockedByKey[key]
            UnifiedCallRecord(
                id = "guest_screened_${evt.occurredAtMillis}_$index",
                rawNumber = evt.phoneNumber,
                numberKey = key,
                displayName = contact?.name
                    ?: dir?.callerName
                    ?: evt.callerName.ifBlank { evt.phoneNumber },
                direction = if (evt.actionTaken == "BLOCKED") "BLOCKED" else "INCOMING",
                actionTaken = evt.actionTaken,
                spamScore = maxOf(evt.spamScore, dir?.spamScore?.toInt() ?: 0),
                verifiedBusiness = dir?.verifiedBusiness == true,
                category = dir?.category ?: if (evt.spamScore >= 50) "SCAM_FRAUD" else "LOCAL_SCREEN",
                stirVerification = evt.stirVerification,
                isBlocked = blocked != null || evt.actionTaken == "BLOCKED",
                isContact = contact != null,
                timestampMillis = evt.occurredAtMillis,
                durationSeconds = 0L,
                isCloudEvent = false
            )
        }

        val deviceRecords = deviceLogs.map { log ->
            val dir = dirByKey[log.numberKey]
            val contact = contactsByKey[log.numberKey]
            val blocked = blockedByKey[log.numberKey]
            val isBlocked = blocked != null || log.callType == "BLOCKED"
            UnifiedCallRecord(
                id = "dev_${log.id}",
                rawNumber = log.phoneNumber,
                numberKey = log.numberKey,
                displayName = contact?.name
                    ?: log.cachedContactName?.takeIf { it.isNotBlank() }
                    ?: dir?.callerName
                    ?: log.phoneNumber,
                direction = log.callType,
                actionTaken = if (isBlocked) "BLOCKED" else "ALLOWED",
                spamScore = if (blocked != null) 100 else dir?.spamScore?.toInt() ?: 0,
                verifiedBusiness = dir?.verifiedBusiness == true,
                category = dir?.category ?: if (contact != null) "CONTACT" else "UNKNOWN",
                stirVerification = "NOT_VERIFIED",
                isBlocked = isBlocked,
                isContact = contact != null,
                timestampMillis = log.timestampMillis,
                durationSeconds = log.durationSeconds,
                isCloudEvent = false
            )
        }

        (localScreenedRecords + deviceRecords).sortedByDescending { it.timestampMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    fun refreshDeviceData(context: Context) {
        viewModelScope.launch {
            _deviceCallLogs.value = DeviceContentReader.readDeviceCallLogs(context)
            _deviceContacts.value = DeviceContentReader.readDeviceContacts(context)
            _localScreenedEvents.value = screeningCache.peekPendingScreenedEvents()
            _blockedNumbers.value = screeningCache.getBlockedNumbersList()
            _cachedDirectory.value = screeningCache.getCachedDirectoryEntries()
            _guestProfile.value = buildGuestProfile()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun inspectNumber(rawNumber: String) {
        _inspectedNumber.value = rawNumber
    }

    fun dismissInspector() {
        _inspectedNumber.value = null
    }

    fun updatePreferences(
        spamProtectionEnabled: Boolean,
        autoBlockHighRisk: Boolean,
        notificationsEnabled: Boolean,
        themeMode: ThemeMode
    ) {
        screeningCache.spamProtectionEnabled = spamProtectionEnabled
        screeningCache.autoBlockHighRisk = autoBlockHighRisk
        screeningCache.notificationsEnabled = notificationsEnabled
        screeningCache.guestThemeMode = themeMode.name
        _themeMode.value = themeMode
        _guestProfile.value = buildGuestProfile()
    }

    fun blockNumber(rawNumber: String, label: String, reason: String, blockMode: String = "REJECT") {
        val res = screeningCache.upsertLocalBlockedNumber(rawNumber, label, reason, blockMode)
        if (res.isSuccess) {
            _blockedNumbers.value = screeningCache.getBlockedNumbersList()
            _snackbarEvents.tryEmit("Number blocked locally on this device")
        } else {
            _snackbarEvents.tryEmit(res.exceptionOrNull()?.message ?: "Enter a valid phone number")
        }
    }

    fun unblockNumber(blockId: String) {
        screeningCache.removeLocalBlockedNumber(blockId)
        _blockedNumbers.value = screeningCache.getBlockedNumbersList()
        _snackbarEvents.tryEmit("Number unblocked")
    }

    fun toggleBlockMode(item: BlockedNumber) {
        screeningCache.toggleLocalBlockMode(item.phoneNumber)
        _blockedNumbers.value = screeningCache.getBlockedNumbersList()
    }

    fun promptGoogleSignInForCloudFeature(featureName: String) {
        _signInPromptEvents.tryEmit("Sign in with Google to $featureName and sync across devices.")
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5000L
    }
}
