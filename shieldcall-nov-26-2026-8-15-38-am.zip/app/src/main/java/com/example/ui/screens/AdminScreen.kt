package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminMember
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.SpamReport
import com.example.data.model.SystemAlert
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedBusiness
import com.example.data.repository.DirectoryAdminRepository
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SpamRiskBadge
import com.example.ui.components.SystemAlertBanner
import com.example.ui.theme.JetBrainsMonoFamily
import kotlin.math.roundToInt

@Composable
fun AdminScreen(
    pendingReportsState: UiState<List<SpamReport>>,
    pendingBusinessesState: UiState<List<VerifiedBusiness>>,
    directoryEntries: List<CallerDirectoryEntry>,
    allUsers: List<UserProfile>,
    adminsList: List<AdminMember>,
    systemAlerts: List<SystemAlert>,
    onModerateReport: (SpamReport, Boolean) -> Unit,
    onModerateBusiness: (VerifiedBusiness, Boolean) -> Unit,
    onUpsertDirectoryEntry: (String, String, String, Int, Boolean, String) -> Unit,
    onDeleteDirectoryEntry: (String) -> Unit,
    onPublishAlert: (String, String, String) -> Unit,
    onDeleteAlert: (String) -> Unit,
    onGrantAdmin: (String, String, String) -> Unit,
    onRevokeAdmin: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showUpsertDirDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<CallerDirectoryEntry?>(null) }
    var showAlertDialog by remember { mutableStateOf(false) }
    var showGrantAdminDialog by remember { mutableStateOf(false) }

    val pendingReports = (pendingReportsState as? UiState.Success)?.data.orEmpty()
    val pendingBusinesses = (pendingBusinessesState as? UiState.Success)?.data.orEmpty()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            // Admin Header + KPIs
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = "Admin console",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Admin Command Center",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdminKpiCard("Users", "${allUsers.size}", Modifier.weight(1f))
                    AdminKpiCard("Directory", "${directoryEntries.size}", Modifier.weight(1f))
                    AdminKpiCard("Reports", "${pendingReports.size}", Modifier.weight(1f))
                    AdminKpiCard("Biz Queue", "${pendingBusinesses.size}", Modifier.weight(1f))
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Reports (${pendingReports.size})") },
                    modifier = Modifier.testTag("admin_tab_reports")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Business (${pendingBusinesses.size})") },
                    modifier = Modifier.testTag("admin_tab_businesses")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Directory") },
                    modifier = Modifier.testTag("admin_tab_directory")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Alerts & Team") },
                    modifier = Modifier.testTag("admin_tab_alerts")
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        when (pendingReportsState) {
                            UiState.Loading -> item { CircularProgressIndicator() }
                            is UiState.Error -> item { Text(pendingReportsState.message, color = MaterialTheme.colorScheme.error) }
                            is UiState.Success -> {
                                if (pendingReportsState.data.isEmpty()) {
                                    item {
                                        EmptyStateCard(
                                            title = "Moderation Queue Clear",
                                            subtitle = "All community spam reports have been reviewed.",
                                            showIllustration = false
                                        )
                                    }
                                } else {
                                    items(pendingReportsState.data, key = { it.id }) { report ->
                                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = report.reportedName.ifBlank { report.displayNumber },
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = report.category,
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = MaterialTheme.colorScheme.error
                                                    )
                                                }
                                                Text(
                                                    text = "${report.displayNumber} • By ${report.reporterName}",
                                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (report.comment.isNotBlank()) {
                                                    Text(report.comment, style = MaterialTheme.typography.bodySmall)
                                                }
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { onModerateReport(report, true) },
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .testTag("approve_report_${report.id}")
                                                    ) {
                                                        Icon(Icons.Filled.Check, contentDescription = null)
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Approve")
                                                    }
                                                    OutlinedButton(
                                                        onClick = { onModerateReport(report, false) },
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .testTag("reject_report_${report.id}")
                                                    ) {
                                                        Icon(Icons.Filled.Close, contentDescription = null)
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Reject")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        when (pendingBusinessesState) {
                            UiState.Loading -> item { CircularProgressIndicator() }
                            is UiState.Error -> item { Text(pendingBusinessesState.message, color = MaterialTheme.colorScheme.error) }
                            is UiState.Success -> {
                                if (pendingBusinessesState.data.isEmpty()) {
                                    item {
                                        EmptyStateCard(
                                            title = "No Pending Verifications",
                                            subtitle = "New verified business badge applications will appear here.",
                                            showIllustration = false
                                        )
                                    }
                                } else {
                                    items(pendingBusinessesState.data, key = { it.id }) { biz ->
                                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(biz.businessName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                                Text("${biz.displayNumber} • ${biz.category}", style = MaterialTheme.typography.bodySmall)
                                                if (biz.website.isNotBlank()) {
                                                    Text(biz.website, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                                }
                                                if (biz.description.isNotBlank()) {
                                                    Text(biz.description, style = MaterialTheme.typography.bodySmall)
                                                }
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { onModerateBusiness(biz, true) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .testTag("verify_biz_${biz.id}")
                                                    ) {
                                                        Text("Verify Badge")
                                                    }
                                                    OutlinedButton(
                                                        onClick = { onModerateBusiness(biz, false) },
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .testTag("reject_biz_${biz.id}")
                                                    ) {
                                                        Text("Reject")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        item {
                            SectionHeader(
                                title = "Caller Directory (${directoryEntries.size})",
                                actionLabel = "Add Entry",
                                onAction = {
                                    editingEntry = null
                                    showUpsertDirDialog = true
                                }
                            )
                        }
                        items(directoryEntries, key = { it.numberKey }) { entry ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(entry.callerName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${entry.displayNumber} • ${entry.category}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    SpamRiskBadge(
                                        spamScore = entry.spamScore.toInt(),
                                        verifiedBusiness = entry.verifiedBusiness,
                                        isBlocked = false
                                    )
                                    TextButton(onClick = {
                                        editingEntry = entry
                                        showUpsertDirDialog = true
                                    }) {
                                        Text("Edit")
                                    }
                                    IconButton(onClick = { onDeleteDirectoryEntry(entry.numberKey) }) {
                                        Icon(
                                            imageVector = Icons.Filled.Delete,
                                            contentDescription = "Delete entry",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        item {
                            SectionHeader(
                                title = "Broadcast Security Alerts (${systemAlerts.size})",
                                actionLabel = "New Alert",
                                onAction = { showAlertDialog = true }
                            )
                        }
                        if (systemAlerts.isEmpty()) {
                            item {
                                Button(
                                    onClick = { showAlertDialog = true },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("publish_alert_button")
                                ) {
                                    Icon(Icons.Filled.Campaign, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Broadcast Real-Time Spam Alert")
                                }
                            }
                        } else {
                            items(systemAlerts, key = { "admin_alert_${it.id}" }) { alert ->
                                SystemAlertBanner(
                                    alert = alert,
                                    onDismiss = { onDeleteAlert(alert.id) }
                                )
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            SectionHeader(
                                title = "Admin Roster (${adminsList.size})",
                                actionLabel = "Grant Admin",
                                onAction = { showGrantAdminDialog = true }
                            )
                        }
                        items(adminsList, key = { it.uid }) { member ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(member.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(member.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = { onRevokeAdmin(member.uid) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Revoke admin", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }

                        item {
                            SectionHeader(title = "Registered Users (${allUsers.size})")
                        }
                        items(allUsers.take(25), key = { it.userId }) { user ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(user.displayName, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = "${user.email.orEmpty()} • UID: ${user.userId.take(10)}...",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${user.totalSpamBlocked} blocked",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showUpsertDirDialog) {
        UpsertDirectoryDialog(
            initial = editingEntry,
            onDismiss = { showUpsertDirDialog = false },
            onSave = { num, name, cat, score, verified, vis ->
                onUpsertDirectoryEntry(num, name, cat, score, verified, vis)
                showUpsertDirDialog = false
            }
        )
    }

    if (showAlertDialog) {
        PublishAlertDialog(
            onDismiss = { showAlertDialog = false },
            onPublish = { title, msg, severity ->
                onPublishAlert(title, msg, severity)
                showAlertDialog = false
            }
        )
    }

    if (showGrantAdminDialog) {
        GrantAdminDialog(
            onDismiss = { showGrantAdminDialog = false },
            onGrant = { uid, email, name ->
                onGrantAdmin(uid, email, name)
                showGrantAdminDialog = false
            }
        )
    }
}

@Composable
private fun AdminKpiCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFamily),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun UpsertDirectoryDialog(
    initial: CallerDirectoryEntry?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int, Boolean, String) -> Unit
) {
    var phone by remember { mutableStateOf(initial?.displayNumber.orEmpty()) }
    var name by remember { mutableStateOf(initial?.callerName.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: "SCAM_FRAUD") }
    var score by remember { mutableFloatStateOf((initial?.spamScore ?: 80L).toFloat()) }
    var verified by remember { mutableStateOf(initial?.verifiedBusiness ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Directory Entry" else "Edit Directory Entry") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    enabled = initial == null,
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 80) name = it },
                    label = { Text("Caller / Business Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Category", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("VERIFIED_BUSINESS", "SCAM_FRAUD", "ROBOCALL", "TELEMARKETER").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.take(8), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Text("Spam Score: ${score.roundToInt()}%", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = score,
                    onValueChange = { score = it },
                    valueRange = 0f..100f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Verified Business Badge")
                    Switch(checked = verified, onCheckedChange = { verified = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(phone, name, category, score.roundToInt(), verified, "PUBLIC") },
                enabled = phone.filter { it.isDigit() }.length >= 3 && name.trim().isNotEmpty()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun PublishAlertDialog(
    onDismiss: () -> Unit,
    onPublish: (String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf("WARNING") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Broadcast Security Alert") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { if (it.length <= 80) title = it },
                    label = { Text("Alert Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { if (it.length <= 300) message = it },
                    label = { Text("Alert Message") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("INFO", "WARNING", "CRITICAL").forEach { sev ->
                        FilterChip(
                            selected = severity == sev,
                            onClick = { severity = sev },
                            label = { Text(sev) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onPublish(title, message, severity) },
                enabled = title.trim().length >= 2 && message.trim().length >= 2
            ) {
                Text("Publish")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun GrantAdminDialog(
    onDismiss: () -> Unit,
    onGrant: (String, String, String) -> Unit
) {
    var uid by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Grant Admin Role") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = uid,
                    onValueChange = { uid = it },
                    label = { Text("User Firebase UID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("User Google Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onGrant(uid, email, name) },
                enabled = uid.isNotBlank() && email.contains("@")
            ) {
                Text("Grant")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
