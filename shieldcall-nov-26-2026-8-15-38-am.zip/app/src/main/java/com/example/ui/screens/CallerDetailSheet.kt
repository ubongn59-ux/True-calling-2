package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CallerLookupResult
import com.example.data.repository.DirectoryAdminRepository
import com.example.ui.components.CallerAvatar
import com.example.ui.components.SpamRiskBadge
import com.example.ui.components.VerifiedBusinessPill
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.WarningAmber
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallerDetailSheet(
    lookup: CallerLookupResult,
    onDismiss: () -> Unit,
    onBlock: (rawNumber: String, label: String, reason: String, mode: String) -> Unit,
    onUnblock: (blockId: String) -> Unit,
    onSubmitReport: (rawNumber: String, reportedName: String, category: String, comment: String) -> Unit,
    onSubmitRating: (rawNumber: String, stars: Int, review: String) -> Unit
) {
    val context = LocalContext.current
    val dir = lookup.directoryEntry
    val spamScore = if (lookup.blockedEntry != null) 100 else dir?.spamScore?.toInt() ?: 0
    val verified = dir?.verifiedBusiness == true

    var showReportDialog by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var selectedStars by remember { mutableIntStateOf(5) }
    var reviewText by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CallerAvatar(
                    name = lookup.resolvedName,
                    spamScore = spamScore,
                    verifiedBusiness = verified,
                    isBlocked = lookup.blockedEntry != null
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = lookup.resolvedName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (verified) VerifiedBusinessPill()
                    }
                    Text(
                        text = lookup.displayNumber,
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SpamRiskBadge(
                    spamScore = spamScore,
                    verifiedBusiness = verified,
                    isBlocked = lookup.blockedEntry != null
                )
            }

            // Spam risk gauge card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Spam Risk Index",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Text(
                            text = "$spamScore / 100",
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                            color = if (spamScore >= 70) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (spamScore / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = when {
                            spamScore >= 70 -> MaterialTheme.colorScheme.error
                            spamScore >= 35 -> WarningAmber
                            else -> MaterialTheme.colorScheme.tertiary
                        }
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Spam Reports: ${dir?.spamReportsCount ?: 0}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Safe Votes: ${dir?.safeReportsCount ?: 0}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val avgText = if ((dir?.ratingsCount ?: 0L) > 0L) {
                            String.format(Locale.getDefault(), "%.1f★ (%d)", dir?.averageRating ?: 0.0, dir?.ratingsCount ?: 0L)
                        } else {
                            "No ratings"
                        }
                        Text(
                            text = avgText,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${lookup.displayNumber}"))
                        context.startActivity(dialIntent)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("detail_dial_button")
                ) {
                    Icon(Icons.Filled.Call, contentDescription = "Dial number", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call")
                }

                if (lookup.blockedEntry != null) {
                    Button(
                        onClick = { onUnblock(lookup.blockedEntry.id) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("detail_unblock_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Unblock", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Unblock")
                    }
                } else {
                    Button(
                        onClick = { showBlockDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("detail_block_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Filled.Block, contentDescription = "Block number", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Block")
                    }
                }
            }

            OutlinedButton(
                onClick = { showReportDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("detail_report_button")
            ) {
                Icon(Icons.Filled.Flag, contentDescription = "Report spam or safe", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Report Spam or Mark Safe")
            }

            HorizontalDivider()

            // Rate Caller Section
            Text(
                text = "Rate this Caller",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                (1..5).forEach { star ->
                    IconButton(
                        onClick = { selectedStars = star },
                        modifier = Modifier.testTag("rate_star_$star")
                    ) {
                        Icon(
                            imageVector = if (star <= selectedStars) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = "Rate $star stars",
                            tint = if (star <= selectedStars) WarningAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$selectedStars / 5",
                    style = MaterialTheme.typography.labelLarge
                )
            }

            OutlinedTextField(
                value = reviewText,
                onValueChange = { if (it.length <= 280) reviewText = it },
                label = { Text("Share your experience (optional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rating_review_input"),
                maxLines = 3
            )

            Button(
                onClick = {
                    onSubmitRating(lookup.displayNumber, selectedStars, reviewText)
                    reviewText = ""
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("submit_rating_button")
            ) {
                Text("Submit Rating")
            }

            if (lookup.ratings.isNotEmpty()) {
                Text(
                    text = "Community Reviews (${lookup.ratings.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                lookup.ratings.take(5).forEach { rating ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(rating.userName, style = MaterialTheme.typography.labelLarge)
                                Text(
                                    text = "★".repeat(rating.stars.toInt().coerceIn(1, 5)),
                                    color = WarningAmber,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                            if (rating.review.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(rating.review, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            if (lookup.approvedReports.isNotEmpty()) {
                Text(
                    text = "Verified Community Reports (${lookup.approvedReports.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                lookup.approvedReports.take(5).forEach { report ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "${report.category} • ${report.reportedName.ifBlank { "Reported Caller" }}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (report.comment.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(report.comment, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showReportDialog) {
        ReportSpamDialog(
            initialNumber = lookup.displayNumber,
            initialName = lookup.resolvedName,
            onDismiss = { showReportDialog = false },
            onSubmit = { num, name, cat, comment ->
                onSubmitReport(num, name, cat, comment)
                showReportDialog = false
            }
        )
    }

    if (showBlockDialog) {
        BlockNumberDialog(
            initialNumber = lookup.displayNumber,
            initialLabel = lookup.resolvedName,
            onDismiss = { showBlockDialog = false },
            onConfirm = { num, label, reason, mode ->
                onBlock(num, label, reason, mode)
                showBlockDialog = false
            }
        )
    }
}

@Composable
fun ReportSpamDialog(
    initialNumber: String = "",
    initialName: String = "",
    onDismiss: () -> Unit,
    onSubmit: (rawNumber: String, reportedName: String, category: String, comment: String) -> Unit
) {
    var phoneInput by remember { mutableStateOf(initialNumber) }
    var nameInput by remember { mutableStateOf(initialName) }
    var selectedCategory by remember { mutableStateOf("SCAM_FRAUD") }
    var commentInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Report Phone Number") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_phone_input")
                )
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { if (it.length <= 80) nameInput = it },
                    label = { Text("Caller / Business Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_name_input")
                )
                Text("Category", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DirectoryAdminRepository.REPORT_CATEGORIES.take(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.replace("_", " "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DirectoryAdminRepository.REPORT_CATEGORIES.drop(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.replace("_", " "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(
                    value = commentInput,
                    onValueChange = { if (it.length <= 300) commentInput = it },
                    label = { Text("Details (e.g. robocall, bank impersonation)") },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_comment_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(phoneInput, nameInput, selectedCategory, commentInput) },
                enabled = phoneInput.filter { it.isDigit() }.length >= 3,
                modifier = Modifier.testTag("confirm_report_button")
            ) {
                Text("Submit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun BlockNumberDialog(
    initialNumber: String = "",
    initialLabel: String = "",
    onDismiss: () -> Unit,
    onConfirm: (rawNumber: String, label: String, reason: String, blockMode: String) -> Unit
) {
    var phoneInput by remember { mutableStateOf(initialNumber) }
    var labelInput by remember { mutableStateOf(initialLabel) }
    var reasonInput by remember { mutableStateOf("Unwanted spam / robocall") }
    var blockMode by remember { mutableStateOf("REJECT") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Block Phone Number") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("block_phone_input")
                )
                OutlinedTextField(
                    value = labelInput,
                    onValueChange = { if (it.length <= 80) labelInput = it },
                    label = { Text("Label (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reasonInput,
                    onValueChange = { if (it.length <= 160) reasonInput = it },
                    label = { Text("Reason") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = blockMode == "REJECT",
                        onClick = { blockMode = "REJECT" },
                        label = { Text("Reject Call") }
                    )
                    FilterChip(
                        selected = blockMode == "SILENCE",
                        onClick = { blockMode = "SILENCE" },
                        label = { Text("Silence Ring") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(phoneInput, labelInput, reasonInput, blockMode) },
                enabled = phoneInput.filter { it.isDigit() }.length >= 3,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.testTag("confirm_block_button")
            ) {
                Text("Block")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
