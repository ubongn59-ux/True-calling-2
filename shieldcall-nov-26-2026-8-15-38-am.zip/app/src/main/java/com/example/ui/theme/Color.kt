package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette — Crisp Cobalt Shield & Clean Slate
val CobaltPrimary = Color(0xFF0D47A1)
val CobaltOnPrimary = Color(0xFFFFFFFF)
val CobaltPrimaryContainer = Color(0xFFD8E6FF)
val CobaltOnPrimaryContainer = Color(0xFF001B47)

val CyanSecondary = Color(0xFF0284C7)
val CyanOnSecondary = Color(0xFFFFFFFF)
val CyanSecondaryContainer = Color(0xFFE0F2FE)
val CyanOnSecondaryContainer = Color(0xFF00263D)

val EmeraldTertiary = Color(0xFF059669)
val EmeraldOnTertiary = Color(0xFFFFFFFF)
val EmeraldTertiaryContainer = Color(0xFFD1FAE5)
val EmeraldOnTertiaryContainer = Color(0xFF00291B)

val SpamCrimson = Color(0xFFDC2626)
val SpamOnCrimson = Color(0xFFFFFFFF)
val SpamCrimsonContainer = Color(0xFFFEE2E2)
val SpamOnCrimsonContainer = Color(0xFF450A0A)

val LightBackground = Color(0xFFF4F7FB)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFE8EEF6)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Palette — Deep Obsidian Navy & Luminous Cyan
val DarkCobaltPrimary = Color(0xFF60A5FA)
val DarkCobaltOnPrimary = Color(0xFF00285E)
val DarkCobaltPrimaryContainer = Color(0xFF1E3A8A)
val DarkCobaltOnPrimaryContainer = Color(0xFFDBEAFE)

val DarkCyanSecondary = Color(0xFF38BDF8)
val DarkCyanOnSecondary = Color(0xFF00324D)
val DarkCyanSecondaryContainer = Color(0xFF0C4A6E)
val DarkCyanOnSecondaryContainer = Color(0xFFE0F2FE)

val DarkEmeraldTertiary = Color(0xFF34D399)
val DarkEmeraldOnTertiary = Color(0xFF003826)
val DarkEmeraldTertiaryContainer = Color(0xFF064E3B)
val DarkEmeraldOnTertiaryContainer = Color(0xFFD1FAE5)

val DarkSpamCrimson = Color(0xFFF87171)
val DarkSpamOnCrimson = Color(0xFF450A0A)
val DarkSpamCrimsonContainer = Color(0xFF7F1D1D)
val DarkSpamOnCrimsonContainer = Color(0xFFFEE2E2)

val DarkBackground = Color(0xFF090F1D)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkSurface = Color(0xFF11192C)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

// Semantic Status Accents
val WarningAmber = Color(0xFFD97706)
val WarningAmberSoft = Color(0xFFFEF3C7)
val WarningAmberDarkSoft = Color(0xFF451A03)
