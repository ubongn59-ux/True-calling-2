package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ColorTokenLowLight = androidx.compose.ui.graphics.Color(0xFFF8FAFC)

private val LightColors = lightColorScheme(
    primary = CobaltPrimary,
    onPrimary = CobaltOnPrimary,
    primaryContainer = CobaltPrimaryContainer,
    onPrimaryContainer = CobaltOnPrimaryContainer,
    secondary = CyanSecondary,
    onSecondary = CyanOnSecondary,
    secondaryContainer = CyanSecondaryContainer,
    onSecondaryContainer = CyanOnSecondaryContainer,
    tertiary = EmeraldTertiary,
    onTertiary = EmeraldOnTertiary,
    tertiaryContainer = EmeraldTertiaryContainer,
    onTertiaryContainer = EmeraldOnTertiaryContainer,
    error = SpamCrimson,
    onError = SpamOnCrimson,
    errorContainer = SpamCrimsonContainer,
    onErrorContainer = SpamOnCrimsonContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    surfaceContainerLowest = LightSurface,
    surfaceContainerLow = ColorTokenLowLight,
    surfaceContainer = LightSurfaceVariant,
)

private val DarkColors = darkColorScheme(
    primary = DarkCobaltPrimary,
    onPrimary = DarkCobaltOnPrimary,
    primaryContainer = DarkCobaltPrimaryContainer,
    onPrimaryContainer = DarkCobaltOnPrimaryContainer,
    secondary = DarkCyanSecondary,
    onSecondary = DarkCyanOnSecondary,
    secondaryContainer = DarkCyanSecondaryContainer,
    onSecondaryContainer = DarkCyanOnSecondaryContainer,
    tertiary = DarkEmeraldTertiary,
    onTertiary = DarkEmeraldOnTertiary,
    tertiaryContainer = DarkEmeraldTertiaryContainer,
    onTertiaryContainer = DarkEmeraldOnTertiaryContainer,
    error = DarkSpamCrimson,
    onError = DarkSpamOnCrimson,
    errorContainer = DarkSpamCrimsonContainer,
    onErrorContainer = DarkSpamOnCrimsonContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    surfaceContainerLowest = DarkBackground,
    surfaceContainerLow = DarkSurface,
    surfaceContainer = DarkSurfaceVariant,
)

val CallShieldShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

enum class ThemeMode {
    SYSTEM, LIGHT, DARK;

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name == raw } ?: SYSTEM
    }
}

@Composable
fun CallShieldTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (isDark) DarkColors else LightColors,
        typography = CallShieldTypography,
        shapes = CallShieldShapes,
        content = content
    )
}
