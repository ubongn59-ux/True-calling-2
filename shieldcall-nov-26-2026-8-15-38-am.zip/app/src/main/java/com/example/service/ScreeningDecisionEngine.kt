package com.example.service

import com.example.util.CachedDirectoryMatch

data class ScreeningDecision(
    val callerName: String,
    val spamScore: Int,
    val actionTaken: String,
    val shouldReject: Boolean,
    val shouldSilence: Boolean,
    val badgeSubtitle: String
)

object ScreeningDecisionEngine {

    fun evaluate(
        displayNumber: String,
        protectionEnabled: Boolean,
        autoBlockHighRisk: Boolean,
        stirStatus: String,
        blockedMatch: Pair<String, String>?,
        dirMatch: CachedDirectoryMatch?
    ): ScreeningDecision {
        val computedSpamScore = when {
            blockedMatch != null -> 100
            dirMatch != null && stirStatus == "FAILED" -> maxOf(dirMatch.spamScore, 75)
            dirMatch != null -> dirMatch.spamScore
            stirStatus == "FAILED" -> 70
            else -> 0
        }.coerceIn(0, 100)

        val callerName = when {
            blockedMatch != null -> blockedMatch.first.ifBlank { "Blocked Caller" }
            dirMatch != null -> dirMatch.callerName
            stirStatus == "FAILED" -> "Unverified / Possible Spoof"
            else -> displayNumber
        }

        val isVerifiedBusiness = dirMatch?.verifiedBusiness == true
        val isPersonalReject = blockedMatch?.second == "REJECT"
        val isPersonalSilence = blockedMatch?.second == "SILENCE"
        val shouldReject = protectionEnabled && (
            isPersonalReject ||
                (!isPersonalSilence && autoBlockHighRisk && computedSpamScore >= 75 && !isVerifiedBusiness)
            )
        val shouldSilence = protectionEnabled && !shouldReject && (
            isPersonalSilence ||
                (computedSpamScore in 50..74 && !isVerifiedBusiness)
            )

        val actionTaken = when {
            shouldReject -> "BLOCKED"
            shouldSilence -> "SILENCED"
            else -> "ALLOWED"
        }

        val badgeSubtitle = when {
            isVerifiedBusiness -> "Verified Business"
            computedSpamScore >= 40 -> "Spam Risk $computedSpamScore%"
            stirStatus == "PASSED" -> "Carrier Verified"
            stirStatus == "FAILED" -> "Carrier Check Failed"
            else -> "Community Identified"
        }

        return ScreeningDecision(
            callerName = callerName,
            spamScore = computedSpamScore,
            actionTaken = actionTaken,
            shouldReject = shouldReject,
            shouldSilence = shouldSilence,
            badgeSubtitle = badgeSubtitle
        )
    }
}
