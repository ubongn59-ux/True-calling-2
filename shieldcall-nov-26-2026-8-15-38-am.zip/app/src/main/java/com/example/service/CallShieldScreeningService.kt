package com.example.service

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.Connection
import androidx.annotation.RequiresApi
import com.example.util.CallNotificationHelper
import com.example.util.PendingScreenedEvent
import com.example.util.PhoneNumberNormalizer
import com.example.util.ScreeningCache

@RequiresApi(Build.VERSION_CODES.Q)
class CallShieldScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val isIncoming = callDetails.callDirection == Call.Details.DIRECTION_INCOMING
        if (!isIncoming) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val rawNumber = callDetails.handle?.schemeSpecificPart.orEmpty()
        val numberKey = PhoneNumberNormalizer.toKey(rawNumber)
        val displayNumber = PhoneNumberNormalizer.formatDisplay(rawNumber)

        val cache = ScreeningCache(applicationContext)
        val stirStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            when (callDetails.callerNumberVerificationStatus) {
                Connection.VERIFICATION_STATUS_PASSED -> "PASSED"
                Connection.VERIFICATION_STATUS_FAILED -> "FAILED"
                else -> "NOT_VERIFIED"
            }
        } else {
            "NOT_VERIFIED"
        }

        val blockedMatch = if (numberKey.isNotEmpty()) cache.getBlockedMode(numberKey) else null
        val dirMatch = if (numberKey.isNotEmpty()) cache.findDirectoryMatch(numberKey) else null

        val decision = ScreeningDecisionEngine.evaluate(
            displayNumber = displayNumber,
            protectionEnabled = cache.spamProtectionEnabled,
            autoBlockHighRisk = cache.autoBlockHighRisk,
            stirStatus = stirStatus,
            blockedMatch = blockedMatch,
            dirMatch = dirMatch
        )

        val response = CallResponse.Builder()
            .setDisallowCall(decision.shouldReject)
            .setRejectCall(decision.shouldReject)
            .setSilenceCall(decision.shouldSilence)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()

        respondToCall(callDetails, response)

        cache.enqueueScreenedEvent(
            PendingScreenedEvent(
                phoneNumber = displayNumber,
                callerName = decision.callerName,
                actionTaken = decision.actionTaken,
                spamScore = decision.spamScore,
                stirVerification = stirStatus,
                occurredAtMillis = System.currentTimeMillis()
            )
        )

        if (cache.notificationsEnabled) {
            when {
                decision.shouldReject -> CallNotificationHelper.showBlockedCallNotification(
                    context = applicationContext,
                    displayNumber = displayNumber,
                    callerName = decision.callerName,
                    reason = if (blockedMatch != null) "Personal Blocklist" else "High Spam Risk (${decision.spamScore}%)"
                )
                dirMatch != null || stirStatus == "FAILED" -> CallNotificationHelper.showCallerIdNotification(
                    context = applicationContext,
                    displayNumber = displayNumber,
                    callerName = decision.callerName,
                    subtitle = decision.badgeSubtitle
                )
            }
        }
    }
}
