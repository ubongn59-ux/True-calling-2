package com.example.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.example.data.model.DeviceCallLogItem
import com.example.data.model.DeviceContactItem
import com.example.util.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DeviceContentReader {

    fun hasCallLogPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) ==
            PackageManager.PERMISSION_GRANTED

    fun hasContactsPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    suspend fun readDeviceCallLogs(context: Context, limit: Int = 100): List<DeviceCallLogItem> =
        withContext(Dispatchers.IO) {
            if (!hasCallLogPermission(context)) return@withContext emptyList()
            val results = mutableListOf<DeviceCallLogItem>()
            val projection = arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
            )
            try {
                context.contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${CallLog.Calls.DATE} DESC"
                )?.use { cursor ->
                    val idIdx = cursor.getColumnIndex(CallLog.Calls._ID)
                    val numIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                    val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                    val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
                    val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
                    val durIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)

                    while (cursor.moveToNext() && results.size < limit) {
                        val number = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                        if (number.isBlank()) continue
                        val key = PhoneNumberNormalizer.toKey(number)
                        if (key.isBlank()) continue
                        val callTypeInt = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                        val callType = when (callTypeInt) {
                            CallLog.Calls.OUTGOING_TYPE -> "OUTGOING"
                            CallLog.Calls.MISSED_TYPE -> "MISSED"
                            CallLog.Calls.BLOCKED_TYPE, CallLog.Calls.REJECTED_TYPE -> "BLOCKED"
                            else -> "INCOMING"
                        }
                        results.add(
                            DeviceCallLogItem(
                                id = if (idIdx >= 0) cursor.getString(idIdx).orEmpty() else "${results.size}",
                                phoneNumber = PhoneNumberNormalizer.formatDisplay(number),
                                numberKey = key,
                                cachedContactName = if (nameIdx >= 0) cursor.getString(nameIdx) else null,
                                callType = callType,
                                timestampMillis = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L,
                                durationSeconds = if (durIdx >= 0) cursor.getLong(durIdx) else 0L
                            )
                        )
                    }
                }
            } catch (_: SecurityException) {
                return@withContext emptyList()
            }
            results
        }

    suspend fun readDeviceContacts(context: Context, limit: Int = 250): List<DeviceContactItem> =
        withContext(Dispatchers.IO) {
            if (!hasContactsPermission(context)) return@withContext emptyList()
            val results = mutableListOf<DeviceContactItem>()
            val seenKeys = HashSet<String>()
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone._ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE
            )
            try {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
                    val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val typeIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)

                    while (cursor.moveToNext() && results.size < limit) {
                        val number = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                        val key = PhoneNumberNormalizer.toKey(number)
                        if (key.isBlank() || !seenKeys.add(key)) continue
                        val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                        val phoneType = if (typeIdx >= 0) cursor.getInt(typeIdx) else ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                            context.resources,
                            phoneType,
                            "Mobile"
                        ).toString()

                        results.add(
                            DeviceContactItem(
                                id = if (idIdx >= 0) cursor.getString(idIdx).orEmpty() else key,
                                name = name.ifBlank { PhoneNumberNormalizer.formatDisplay(number) },
                                phoneNumber = PhoneNumberNormalizer.formatDisplay(number),
                                numberKey = key,
                                label = label
                            )
                        )
                    }
                }
            } catch (_: SecurityException) {
                return@withContext emptyList()
            }
            results
        }
}
