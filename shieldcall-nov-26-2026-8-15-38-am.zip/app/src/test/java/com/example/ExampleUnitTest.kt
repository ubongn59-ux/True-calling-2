package com.example

import com.example.data.model.BlockedNumber
import com.example.data.model.CallerDirectoryEntry
import com.example.data.model.UserProfile
import com.example.service.ScreeningDecisionEngine
import com.example.ui.theme.ThemeMode
import com.example.util.CachedDirectoryMatch
import com.example.util.PhoneNumberNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `phone number normalizer produces safe firestore keys and formatted displays`() {
        assertEquals("18005550199", PhoneNumberNormalizer.toKey("+1 (800) 555-0199"))
        assertEquals("442079460000", PhoneNumberNormalizer.toKey("+44 20 7946 0000"))
        assertEquals("num_91", PhoneNumberNormalizer.toKey("91"))
        assertEquals("", PhoneNumberNormalizer.toKey("abc"))

        assertEquals("+1 (800) 555-0199", PhoneNumberNormalizer.formatDisplay("18005550199"))
        assertEquals("(415) 555-0120", PhoneNumberNormalizer.formatDisplay("4155550120"))
        assertTrue(PhoneNumberNormalizer.isValidPhoneInput("+1-800-555-0199"))
        assertFalse(PhoneNumberNormalizer.isValidPhoneInput("12"))
    }

    @Test
    fun `screening engine rejects personal blocklist even if directory score is low`() {
        val decision = ScreeningDecisionEngine.evaluate(
            displayNumber = "+1 (800) 555-0199",
            protectionEnabled = true,
            autoBlockHighRisk = false,
            stirStatus = "PASSED",
            blockedMatch = "Persistent Telemarketer" to "REJECT",
            dirMatch = null
        )
        assertTrue(decision.shouldReject)
        assertFalse(decision.shouldSilence)
        assertEquals("BLOCKED", decision.actionTaken)
        assertEquals(100, decision.spamScore)
        assertEquals("Persistent Telemarketer", decision.callerName)
    }

    @Test
    fun `screening engine silences personal silence rule and moderate spam`() {
        val silenceRule = ScreeningDecisionEngine.evaluate(
            displayNumber = "(415) 555-0190",
            protectionEnabled = true,
            autoBlockHighRisk = true,
            stirStatus = "NOT_VERIFIED",
            blockedMatch = "Quiet Mode" to "SILENCE",
            dirMatch = null
        )
        assertFalse(silenceRule.shouldReject)
        assertTrue(silenceRule.shouldSilence)
        assertEquals("SILENCED", silenceRule.actionTaken)

        val moderateSpam = ScreeningDecisionEngine.evaluate(
            displayNumber = "(415) 555-0191",
            protectionEnabled = true,
            autoBlockHighRisk = true,
            stirStatus = "NOT_VERIFIED",
            blockedMatch = null,
            dirMatch = CachedDirectoryMatch(
                numberKey = "4155550191",
                callerName = "Survey Caller",
                category = "TELEMARKETER",
                spamScore = 60,
                verifiedBusiness = false
            )
        )
        assertFalse(moderateSpam.shouldReject)
        assertTrue(moderateSpam.shouldSilence)
        assertEquals("SILENCED", moderateSpam.actionTaken)
    }

    @Test
    fun `screening engine protects verified businesses from auto block even on failed STIR`() {
        val decision = ScreeningDecisionEngine.evaluate(
            displayNumber = "(415) 555-0120",
            protectionEnabled = true,
            autoBlockHighRisk = true,
            stirStatus = "FAILED",
            blockedMatch = null,
            dirMatch = CachedDirectoryMatch(
                numberKey = "4155550120",
                callerName = "Northstar Clinic",
                category = "VERIFIED_BUSINESS",
                spamScore = 0,
                verifiedBusiness = true
            )
        )
        assertFalse(decision.shouldReject)
        assertFalse(decision.shouldSilence)
        assertEquals("ALLOWED", decision.actionTaken)
        assertEquals("Verified Business", decision.badgeSubtitle)
    }

    @Test
    fun `screening engine respects protection disabled toggle`() {
        val decision = ScreeningDecisionEngine.evaluate(
            displayNumber = "+1 (800) 555-0199",
            protectionEnabled = false,
            autoBlockHighRisk = true,
            stirStatus = "FAILED",
            blockedMatch = "Blocked" to "REJECT",
            dirMatch = null
        )
        assertFalse(decision.shouldReject)
        assertFalse(decision.shouldSilence)
        assertEquals("ALLOWED", decision.actionTaken)
    }

    @Test
    fun `theme mode enum fallback and model defaults are crash safe`() {
        assertEquals(ThemeMode.DARK, ThemeMode.fromRaw("DARK"))
        assertEquals(ThemeMode.LIGHT, ThemeMode.fromRaw("LIGHT"))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromRaw("UNKNOWN_FUTURE_VALUE"))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromRaw(null))

        val defaultUser = UserProfile()
        assertEquals("USER", defaultUser.role)
        assertTrue(defaultUser.spamProtectionEnabled)

        val defaultDir = CallerDirectoryEntry()
        assertEquals("PUBLIC", defaultDir.visibility)
        assertFalse(defaultDir.verifiedBusiness)

        val defaultBlock = BlockedNumber()
        assertEquals("REJECT", defaultBlock.blockMode)
    }

    @Test
    fun `screening engine auto-blocks high risk spam and failed STIR when enabled`() {
        val highRisk = ScreeningDecisionEngine.evaluate(
            displayNumber = "+1 (800) 555-0144",
            protectionEnabled = true,
            autoBlockHighRisk = true,
            stirStatus = "FAILED",
            blockedMatch = null,
            dirMatch = CachedDirectoryMatch(
                numberKey = "18005550144",
                callerName = "IRS Refund Scam",
                category = "SCAM_FRAUD",
                spamScore = 88,
                verifiedBusiness = false
            )
        )
        assertTrue(highRisk.shouldReject)
        assertFalse(highRisk.shouldSilence)
        assertEquals("BLOCKED", highRisk.actionTaken)
        assertEquals(88, highRisk.spamScore)

        val stirFailedModerate = ScreeningDecisionEngine.evaluate(
            displayNumber = "+1 (800) 555-0155",
            protectionEnabled = true,
            autoBlockHighRisk = true,
            stirStatus = "FAILED",
            blockedMatch = null,
            dirMatch = null
        )
        assertFalse(stirFailedModerate.shouldReject)
        assertTrue(stirFailedModerate.shouldSilence)
        assertEquals("SILENCED", stirFailedModerate.actionTaken)
        assertEquals("Spam Risk 70%", stirFailedModerate.badgeSubtitle)
    }
}
